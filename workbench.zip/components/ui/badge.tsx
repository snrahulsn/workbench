import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const badgeVariants = cva(
  'inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium leading-normal whitespace-nowrap transition-colors',
  {
    variants: {
      variant: {
        default: 'border-border bg-background text-muted-foreground',
        neutral: 'border-border bg-muted text-muted-foreground',
        success: 'border-success-border bg-success-foreground text-success',
        warning: 'border-warning-border bg-warning-foreground text-warning',
        info: 'border-info-border bg-info-foreground text-info',
        destructive: 'border-destructive/25 bg-destructive/10 text-destructive',
        solid: 'border-primary bg-primary text-primary-foreground',
      },
    },
    defaultVariants: { variant: 'default' },
  },
);

export function Badge({ className, variant, ...props }: React.HTMLAttributes<HTMLSpanElement> & VariantProps<typeof badgeVariants>) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}

const chipVariants = cva(
  'inline-flex items-center rounded border px-1.5 py-px text-[10.5px] font-medium leading-normal whitespace-nowrap',
  {
    variants: {
      tone: {
        neutral: 'border-border bg-muted text-muted-foreground',
        info: 'border-info-border bg-info-foreground text-info',
        warning: 'border-warning-border bg-warning-foreground text-warning',
        success: 'border-success-border bg-success-foreground text-success',
        danger: 'border-destructive/25 bg-destructive/10 text-destructive',
        violet: 'border-violet-200 bg-violet-50 text-violet-700',
      },
    },
    defaultVariants: { tone: 'neutral' },
  },
);

export function Chip({ className, tone, ...props }: React.HTMLAttributes<HTMLSpanElement> & VariantProps<typeof chipVariants>) {
  return <span className={cn(chipVariants({ tone }), className)} {...props} />;
}

export { badgeVariants };
