/**
 * Shapes the renderer expects behind each block's `source` key.
 * Anything an application writes into a step must match one of these.
 * Documented for pack authors in docs/SCREEN_SCHEMA.md.
 */

export type Tone = 'neutral' | 'info' | 'warning' | 'success' | 'danger' | 'violet';

export type Tag = { text: string; tone?: Tone };

export type Item = {
  id: string;
  name: string;
  description?: string;
  /** Small labelled chips, drawn right-aligned in declared column order. */
  tags?: Tag[];
  /** Plain text columns, drawn between the name and the tags. */
  meta?: string[];
};

export type Entity = {
  id: string;
  name: string;
  subtitle?: string;
  bullets?: string[];
  initial?: string;
  tone?: Tone;
  /** Footer chips. */
  tags?: Tag[];
};

export type Stat = { label: string; value: string; hint?: string; tone?: Tone };

export type Column = { key: string; label: string; align?: 'left' | 'right'; mono?: boolean; width?: string };
export type Cell = string | number | Tag | null | undefined;
export type TableData = { columns: Column[]; rows: Record<string, Cell>[] };

export type MatrixData = {
  items: Item[];
  /** Item ids switched on, per axis entity. A missing entity means everything is on. */
  enabled: Record<string, string[]>;
};

export type GalleryItem = { id: string; title: string; caption?: string; badge?: string; kind?: 'id' | 'table' | 'letter'; watermark?: string };
export type GalleryData = { items: GalleryItem[] };

export type StepItem = { title: string; detail?: string; state: 'done' | 'running' | 'waiting' };

export type MappingData = {
  columns: [string, string];
  rows: { left: string; right: string | null; state?: string; tone?: Tone }[];
};

export type KeyValues = { label: string; value: string; tone?: Tone }[];

export type FormField = {
  name: string;
  label: string;
  type: 'text' | 'textarea' | 'select' | 'number';
  placeholder?: string;
  options?: { value: string; label: string }[];
  required?: boolean;
};
export type FormData = { fields: FormField[]; values?: Record<string, string> };
