'use client';

import * as React from 'react';
import { Loader2 } from 'lucide-react';
import type { ScreenBlock, Stage } from '@/lib/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  CodeBlock, EntityCardsBlock, FormBlock, GalleryBlock, ItemListBlock, KeyValuesBlock,
  MappingBlock, MarkdownBlock, MatrixBlock, Shell, StatGridBlock, StepsBlock, TableBlock,
} from './blocks';
import type { MatrixData } from './types';

export type ScreenState = {
  /** Every step's data, merged into one bag keyed by data key. */
  data: Record<string, unknown>;
  /** Selections shared between blocks, e.g. which entity a matrix is showing. */
  selections: Record<string, string>;
  busy: boolean;
  submitted: boolean;
  locked: boolean;
};

export type ScreenHandlers = {
  onSelect: (key: string, id: string) => void;
  onMatrixToggle: (source: string, axisId: string, itemId: string, next: boolean) => void;
  onAction: (actionId: string) => void;
  onFormSubmit: (tool: string, values: Record<string, string>) => void;
  onSubmit: () => void;
};

export function Screen({
  stage,
  state,
  handlers,
}: {
  stage: Stage;
  state: ScreenState;
  handlers: ScreenHandlers;
}) {
  const visible = stage.blocks.filter((b) => !b.hideWhenEmpty || state.data[b.source] !== undefined);

  return (
    <div>
      <h2 className="text-xl font-semibold tracking-tight">{stage.name}</h2>
      <p className="mb-5 mt-1 max-w-[72ch] text-[13.5px] leading-relaxed text-muted-foreground">{stage.intent}</p>

      {visible.length === 0 && (
        <Card className="mb-3.5">
          <CardContent className="py-14 text-center text-[13px] text-muted-foreground">
            {state.busy ? (
              <span className="inline-flex items-center gap-2">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Working on this step
              </span>
            ) : (
              'Nothing here yet. Ask for what you need in the conversation.'
            )}
          </CardContent>
        </Card>
      )}

      {visible.map((block, i) => (
        <BlockView key={`${block.source}-${i}`} block={block} state={state} handlers={handlers} />
      ))}

      {stage.submit && (
        <div className="mb-3.5 flex flex-wrap items-center gap-2.5">
          <Button onClick={handlers.onSubmit} disabled={state.busy || state.submitted || state.locked}>
            {state.busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {state.submitted ? 'Done' : stage.submit.label}
          </Button>
          {stage.submit.hint && <span className="text-[12.5px] text-muted-foreground">{stage.submit.hint}</span>}
        </div>
      )}

      <div className="flex flex-wrap gap-2">
        {stage.actions.map((a) => {
          const blocked =
            state.locked ||
            state.busy ||
            (a.requiresSubmit && !state.submitted) ||
            a.requires.some((k) => state.data[k] === undefined);
          return (
            <Button
              key={a.id}
              variant={a.variant === 'primary' ? 'default' : 'outline'}
              size="sm"
              disabled={blocked}
              title={a.hint}
              onClick={() => handlers.onAction(a.id)}
            >
              {a.label}
            </Button>
          );
        })}
      </div>
    </div>
  );
}

function BlockView({
  block,
  state,
  handlers,
}: {
  block: ScreenBlock;
  state: ScreenState;
  handlers: ScreenHandlers;
}) {
  const data = state.data[block.source];

  switch (block.type) {
    case 'markdown':
      return <Shell title={block.title} description={block.description}><MarkdownBlock data={data} /></Shell>;
    case 'key-values':
      return <Shell title={block.title} description={block.description}><KeyValuesBlock data={data} /></Shell>;
    case 'stat-grid':
      return <StatGridBlock data={data} columns={block.columns} />;
    case 'entity-cards': {
      const key = block.selectionKey ?? block.source;
      return (
        <Shell title={block.title} description={block.description}>
          <EntityCardsBlock
            data={data}
            columns={block.columns}
            selectable={block.selectable}
            selected={state.selections[key]}
            onSelect={(id) => handlers.onSelect(key, id)}
          />
        </Shell>
      );
    }
    case 'item-list':
      return <Shell title={block.title} description={block.description} flush><ItemListBlock data={data} /></Shell>;
    case 'matrix': {
      const key = block.selectionKey ?? block.axisSource;
      const axis = state.data[block.axisSource];
      const raw = (data ?? {}) as Partial<MatrixData>;
      const m: MatrixData = { items: Array.isArray(raw.items) ? raw.items : [], enabled: raw.enabled ?? {} };
      const active = state.selections[key] ?? (Array.isArray(axis) ? (axis[0] as { id: string } | undefined)?.id : undefined);
      const onCount = active ? m.items.filter((it) => (m.enabled?.[active] ? m.enabled[active].includes(it.id) : true)).length : m.items.length;
      return (
        <Shell
          title={block.title}
          description={block.description}
          flush
          action={<span className="text-xs text-muted-foreground">{onCount} of {m.items.length} on</span>}
        >
          <MatrixBlock
            data={data}
            axis={axis}
            selected={active}
            readOnly={state.locked}
            onSelect={(id) => handlers.onSelect(key, id)}
            onToggle={(axisId, itemId, next) => handlers.onMatrixToggle(block.source, axisId, itemId, next)}
          />
        </Shell>
      );
    }
    case 'table':
      return <Shell title={block.title} description={block.description} flush><TableBlock data={data} /></Shell>;
    case 'gallery':
      return <Shell title={block.title} description={block.description}><GalleryBlock data={data} columns={block.columns} /></Shell>;
    case 'steps':
      return <Shell title={block.title} description={block.description}><StepsBlock data={data} /></Shell>;
    case 'mapping':
      return <Shell title={block.title} description={block.description} flush><MappingBlock data={data} /></Shell>;
    case 'code':
      return <Shell title={block.title} description={block.description}><CodeBlock data={data} /></Shell>;
    case 'form':
      return (
        <Shell title={block.title} description={block.description}>
          <FormBlock
            data={data}
            busy={state.busy}
            submitLabel={block.submitLabel}
            onSubmit={(values) => handlers.onFormSubmit(block.submitTool, values)}
          />
        </Shell>
      );
    default:
      return null;
  }
}
