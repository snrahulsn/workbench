'use client';

import * as React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Check, Circle, Loader2, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardMeta, CardTitle } from '@/components/ui/card';
import { Badge, Chip } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Table, TBody, TD, TH, THead, TR } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import type {
  Cell, Entity, FormData, GalleryData, Item, KeyValues, MappingData,
  MatrixData, Stat, StepItem, TableData, Tag, Tone,
} from './types';

const toneRing: Record<Tone, string> = {
  neutral: 'bg-muted text-muted-foreground border-border',
  info: 'bg-info-foreground text-info border-info-border',
  warning: 'bg-warning-foreground text-warning border-warning-border',
  success: 'bg-success-foreground text-success border-success-border',
  danger: 'bg-destructive/10 text-destructive border-destructive/25',
  violet: 'bg-violet-50 text-violet-700 border-violet-200',
};

const isTag = (c: Cell): c is Tag => !!c && typeof c === 'object' && 'text' in c;

export function Shell({
  title,
  description,
  action,
  flush,
  children,
}: {
  title?: string;
  description?: string;
  action?: React.ReactNode;
  flush?: boolean;
  children: React.ReactNode;
}) {
  if (!title && !action) return <>{children}</>;
  return (
    <Card className="mb-3.5">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardMeta>{description}</CardMeta>}
        <div className="flex-1" />
        {action}
      </CardHeader>
      <CardContent className={cn(flush && 'p-0')}>{children}</CardContent>
    </Card>
  );
}

/* ------------------------------- text ------------------------------ */

export function MarkdownBlock({ data }: { data: unknown }) {
  const text = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
  return (
    <div className="prose-sm max-w-none text-[13.5px] leading-relaxed [&_a]:underline [&_code]:rounded [&_code]:bg-muted [&_code]:px-1 [&_h3]:mb-1 [&_h3]:mt-3 [&_h3]:font-semibold [&_li]:my-0.5 [&_p]:mb-2 [&_ul]:list-disc [&_ul]:pl-5">
      <ReactMarkdown remarkPlugins={[remarkGfm]}>{text}</ReactMarkdown>
    </div>
  );
}

export function KeyValuesBlock({ data }: { data: unknown }) {
  const rows: KeyValues = Array.isArray(data)
    ? (data as KeyValues)
    : Object.entries((data ?? {}) as Record<string, unknown>).map(([label, value]) => ({ label, value: String(value) }));
  return (
    <dl className="grid gap-x-8 gap-y-3 sm:grid-cols-2 lg:grid-cols-3">
      {rows.map((r, i) => (
        <div key={i}>
          <dt className="mb-0.5 text-[11.5px] font-medium text-muted-foreground">{r.label}</dt>
          <dd className="text-[13.5px]">{r.value}</dd>
        </div>
      ))}
    </dl>
  );
}

/* ------------------------------ stats ------------------------------ */

export function StatGridBlock({ data, columns = 4 }: { data: unknown; columns?: number }) {
  const stats = (Array.isArray(data) ? data : []) as Stat[];
  const toneText: Record<Tone, string> = {
    neutral: '', info: 'text-info', warning: 'text-warning',
    success: 'text-success', danger: 'text-destructive', violet: 'text-violet-700',
  };
  return (
    <div className={cn('mb-3.5 grid gap-2.5', columns === 2 ? 'sm:grid-cols-2' : columns === 3 ? 'sm:grid-cols-3' : 'sm:grid-cols-2 lg:grid-cols-4')}>
      {stats.map((s, i) => (
        <Card key={i}>
          <CardContent className="p-3.5">
            <div className="text-[11.5px] font-medium text-muted-foreground">{s.label}</div>
            <div className={cn('mt-1.5 text-[26px] font-semibold leading-none tracking-tight tabular', toneText[s.tone ?? 'neutral'])}>
              {s.value}
            </div>
            {s.hint && <div className="mt-1.5 text-[11.5px] text-muted-foreground">{s.hint}</div>}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

/* ---------------------------- entities ----------------------------- */

function Avatar({ entity, size = 'md' }: { entity: Entity; size?: 'sm' | 'md' }) {
  return (
    <div
      className={cn(
        'grid shrink-0 place-items-center rounded-md border font-semibold',
        size === 'sm' ? 'h-[22px] w-[22px] text-[10px]' : 'h-[30px] w-[30px] text-xs',
        toneRing[entity.tone ?? 'neutral'],
      )}
    >
      {entity.initial ?? (entity.name ?? '?').slice(0, 1).toUpperCase()}
    </div>
  );
}

export function EntityCardsBlock({
  data,
  columns = 3,
  selectable,
  selected,
  onSelect,
}: {
  data: unknown;
  columns?: number;
  selectable?: boolean;
  selected?: string;
  onSelect?: (id: string) => void;
}) {
  const entities = (Array.isArray(data) ? data : []) as Entity[];
  return (
    <div className={cn('grid gap-2.5', columns === 2 ? 'sm:grid-cols-2' : columns === 4 ? 'sm:grid-cols-2 lg:grid-cols-4' : 'sm:grid-cols-2 lg:grid-cols-3')}>
      {entities.map((e, idx) => (
        <button
          key={e.id ?? idx}
          type="button"
          disabled={!selectable}
          onClick={() => onSelect?.(e.id)}
          className={cn(
            'rounded-lg border bg-card p-3.5 text-left shadow-sm transition-colors',
            selectable && 'hover:border-ring/60',
            selectable && selected === e.id && 'border-primary ring-1 ring-primary',
            !selectable && 'cursor-default',
          )}
        >
          <div className="mb-2.5 flex items-center gap-2.5">
            <Avatar entity={e} />
            <div className="min-w-0">
              <div className="truncate text-[13px] font-medium">{e.name ?? 'Untitled'}</div>
              {e.subtitle && <div className="truncate text-[11px] text-muted-foreground">{e.subtitle}</div>}
            </div>
          </div>
          {!!e.bullets?.length && (
            <ul className="space-y-1">
              {e.bullets.map((b, i) => (
                <li key={i} className="flex gap-2 text-[11.5px] leading-snug text-muted-foreground">
                  <span className="mt-[7px] h-[3px] w-[3px] shrink-0 rounded-full bg-border" />
                  {b}
                </li>
              ))}
            </ul>
          )}
          {!!e.tags?.length && (
            <div className="mt-2.5 flex flex-wrap items-center gap-1.5 border-t pt-2.5">
              {e.tags.map((t, i) => (
                <Chip key={i} tone={t.tone ?? 'neutral'}>{t.text}</Chip>
              ))}
            </div>
          )}
        </button>
      ))}
    </div>
  );
}

/* ------------------------------ items ------------------------------ */

function ItemRow({ item, index, leading }: { item: Item; index?: number; leading?: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[auto_1fr_auto] items-center gap-3 border-b px-4 py-2.5 last:border-b-0">
      <div className="flex w-8 items-center justify-start">
        {leading ?? <span className="text-[11.5px] tabular text-muted-foreground">{index}</span>}
      </div>
      <div className="min-w-0">
        <div className="text-[13px] font-medium">{item.name ?? 'Untitled'}</div>
        {item.description && <div className="mt-0.5 text-[11.5px] leading-snug text-muted-foreground">{item.description}</div>}
      </div>
      <div className="flex items-center gap-2">
        {item.meta?.map((m, i) => (
          <span key={i} className="hidden max-w-[180px] truncate text-[11.5px] text-muted-foreground lg:block">{m}</span>
        ))}
        {item.tags?.map((t, i) => (
          <Chip key={i} tone={t.tone ?? 'neutral'}>{t.text}</Chip>
        ))}
      </div>
    </div>
  );
}

export function ItemListBlock({ data }: { data: unknown }) {
  const items = (Array.isArray(data) ? data : []) as Item[];
  return <div>{items.map((it, i) => <ItemRow key={it.id ?? i} item={it} index={i + 1} />)}</div>;
}

/* ------------------------------ matrix ----------------------------- */

export function MatrixBlock({
  data,
  axis,
  selected,
  onSelect,
  onToggle,
  readOnly,
}: {
  data: unknown;
  axis: unknown;
  selected?: string;
  onSelect?: (id: string) => void;
  onToggle?: (axisId: string, itemId: string, next: boolean) => void;
  readOnly?: boolean;
}) {
  const raw = (data ?? {}) as Partial<MatrixData>;
  const matrix: MatrixData = { items: Array.isArray(raw.items) ? raw.items : [], enabled: raw.enabled ?? {} };
  const entities = (Array.isArray(axis) ? axis : []) as Entity[];
  const active = selected ?? entities[0]?.id;
  const on = (axisId: string, itemId: string) => {
    const list = matrix.enabled?.[axisId];
    return list ? list.includes(itemId) : true;
  };
  const count = (axisId: string) => matrix.items.filter((i) => on(axisId, i.id)).length;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-[216px_1fr]">
      <div className="border-b bg-canvas p-1.5 sm:border-b-0 sm:border-r">
        {entities.map((e, idx) => (
          <button
            key={e.id ?? idx}
            type="button"
            onClick={() => onSelect?.(e.id)}
            className={cn(
              'flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-[12.5px] transition-colors',
              active === e.id ? 'border bg-background font-medium shadow-sm' : 'hover:bg-accent',
            )}
          >
            <Avatar entity={e} size="sm" />
            <span className="min-w-0 flex-1 truncate">{e.name}</span>
            <span className="text-[11px] tabular text-muted-foreground">{count(e.id)}</span>
          </button>
        ))}
      </div>
      <div className="max-h-[480px] overflow-y-auto">
        {matrix.items.map((it, idx) => {
          const enabled = active ? on(active, it.id) : true;
          return (
            <div key={it.id ?? idx} className={cn(!enabled && 'opacity-45')}>
              <ItemRow
                item={it}
                leading={
                  <Switch
                    checked={enabled}
                    disabled={readOnly}
                    onCheckedChange={(v) => active && onToggle?.(active, it.id, v)}
                  />
                }
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------------ table ------------------------------ */

export function TableBlock({ data }: { data: unknown }) {
  const tRaw = (data ?? {}) as Partial<TableData>;
  const t: TableData = { columns: Array.isArray(tRaw.columns) ? tRaw.columns : [], rows: Array.isArray(tRaw.rows) ? tRaw.rows : [] };
  return (
    <Table>
      <THead>
        <TR className="hover:bg-canvas">
          {t.columns.map((c) => (
            <TH key={c.key} className={cn(c.align === 'right' && 'text-right')} style={c.width ? { width: c.width } : undefined}>
              {c.label}
            </TH>
          ))}
        </TR>
      </THead>
      <TBody>
        {t.rows.map((r, i) => (
          <TR key={i}>
            {t.columns.map((c) => {
              const v = r[c.key];
              return (
                <TD key={c.key} className={cn(c.align === 'right' && 'text-right', c.mono && 'font-mono text-[11.5px] text-muted-foreground')}>
                  {isTag(v) ? <Badge variant={tagVariant(v.tone)}>{v.text}</Badge> : (v ?? '—')}
                </TD>
              );
            })}
          </TR>
        ))}
      </TBody>
    </Table>
  );
}

function tagVariant(tone?: Tone) {
  switch (tone) {
    case 'success': return 'success' as const;
    case 'warning': return 'warning' as const;
    case 'info': return 'info' as const;
    case 'danger': return 'destructive' as const;
    default: return 'neutral' as const;
  }
}

/* ----------------------------- gallery ----------------------------- */

function Placeholder({ kind = 'letter' }: { kind?: 'id' | 'table' | 'letter' }) {
  const line = (x: number, y: number, w: number, o = 0.11) => (
    <rect key={`${x}-${y}`} x={x} y={y} width={w} height={3} rx={1.5} fill="currentColor" opacity={o} />
  );
  let inner: React.ReactNode;
  if (kind === 'id') {
    inner = (
      <>
        <rect x={10} y={12} width={32} height={38} rx={3} fill="currentColor" opacity={0.07} />
        {line(50, 14, 58, 0.15)}{line(50, 22, 42)}{line(50, 30, 52)}{line(50, 38, 34)}
        {line(10, 58, 100)}{line(10, 66, 70)}
      </>
    );
  } else if (kind === 'table') {
    inner = (
      <>
        {line(10, 10, 56, 0.16)}
        {Array.from({ length: 7 }).map((_, i) => (
          <React.Fragment key={i}>{line(10, 22 + i * 8, 24)}{line(42, 22 + i * 8, 20)}{line(70, 22 + i * 8, 38)}</React.Fragment>
        ))}
      </>
    );
  } else {
    inner = (
      <>
        <rect x={10} y={10} width={26} height={9} rx={2} fill="currentColor" opacity={0.12} />
        {line(10, 30, 100)}{line(10, 38, 92)}{line(10, 46, 100)}{line(10, 54, 64)}{line(10, 66, 100)}{line(10, 74, 80)}
      </>
    );
  }
  return <svg viewBox="0 0 120 88" className="h-full w-full text-foreground">{inner}</svg>;
}

export function GalleryBlock({ data, columns = 4 }: { data: unknown; columns?: number }) {
  const gRaw = (data ?? {}) as Partial<GalleryData>;
  const g: GalleryData = { items: Array.isArray(gRaw.items) ? gRaw.items : [] };
  return (
    <div className={cn('grid gap-2.5', columns >= 4 ? 'grid-cols-2 lg:grid-cols-4' : 'grid-cols-2 lg:grid-cols-3')}>
      {g.items.map((it, idx) => (
        <div key={it.id ?? idx} className="overflow-hidden rounded-md border bg-card">
          <div className="relative grid h-[124px] place-items-center overflow-hidden bg-canvas">
            <Placeholder kind={it.kind} />
            {it.watermark && (
              <div className="pointer-events-none absolute inset-0 grid -rotate-[20deg] place-items-center text-[7.5px] font-bold tracking-[0.16em] text-foreground/10">
                {it.watermark}
              </div>
            )}
            {it.badge && (
              <span className="absolute right-1.5 top-1.5 rounded border bg-background px-1.5 text-[9.5px] text-muted-foreground">{it.badge}</span>
            )}
          </div>
          <div className="border-t px-2.5 py-2">
            <div className="truncate text-[11.5px] font-medium">{it.title}</div>
            {it.caption && (
              <div className="mt-0.5 flex items-center gap-1 text-[10.5px] text-muted-foreground">
                <Check className="h-2.5 w-2.5 text-success" />
                {it.caption}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ------------------------------ steps ------------------------------ */

export function StepsBlock({ data }: { data: unknown }) {
  const steps = (Array.isArray(data) ? data : []) as StepItem[];
  return (
    <ol className="space-y-0.5">
      {steps.map((s, i) => (
        <li key={i} className={cn('flex items-start gap-3 py-2 text-[13px]', s.state === 'waiting' && 'text-muted-foreground')}>
          <span className="mt-0.5 shrink-0">
            {s.state === 'done' ? (
              <span className="grid h-[17px] w-[17px] place-items-center rounded-full bg-success text-success-foreground">
                <Check className="h-2.5 w-2.5" strokeWidth={3.5} />
              </span>
            ) : s.state === 'running' ? (
              <Loader2 className="h-[17px] w-[17px] animate-spin text-foreground" strokeWidth={2} />
            ) : (
              <Circle className="h-[17px] w-[17px] text-border" strokeWidth={1.5} />
            )}
          </span>
          <span className="min-w-0">
            <span className="block">{s.title}</span>
            {s.detail && <span className="mt-0.5 block text-[11.5px] text-muted-foreground">{s.detail}</span>}
          </span>
        </li>
      ))}
    </ol>
  );
}

/* ----------------------------- mapping ----------------------------- */

export function MappingBlock({ data }: { data: unknown }) {
  const mRaw = (data ?? {}) as Partial<MappingData>;
  const m: MappingData = { columns: (Array.isArray(mRaw.columns) ? mRaw.columns : ['', '']) as [string, string], rows: Array.isArray(mRaw.rows) ? mRaw.rows : [] };
  return (
    <div>
      <div className="grid grid-cols-[1fr_22px_1fr_92px] items-center gap-2.5 border-b bg-canvas px-4 py-2.5 text-[11.5px] text-muted-foreground">
        <div>{m.columns[0]}</div>
        <div />
        <div>{m.columns[1]}</div>
        <div>Status</div>
      </div>
      {m.rows.map((r, i) => (
        <div key={i} className="grid grid-cols-[1fr_22px_1fr_92px] items-center gap-2.5 border-b px-4 py-2.5 last:border-b-0">
          <div className="truncate font-mono text-[11.5px]">{r.left}</div>
          <ArrowRight className="h-3 w-3 text-muted-foreground" />
          <div className={cn('truncate font-mono text-[11.5px]', r.right ? 'text-muted-foreground' : 'text-muted-foreground/60')}>
            {r.right ?? 'not connected'}
          </div>
          <div>{r.state && <Badge variant={tagVariant(r.tone)}>{r.state}</Badge>}</div>
        </div>
      ))}
    </div>
  );
}

/* ------------------------------ code ------------------------------- */

export function CodeBlock({ data }: { data: unknown }) {
  const text = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
  return (
    <pre className="overflow-x-auto rounded-md border bg-canvas px-3.5 py-3 font-mono text-[11.5px] leading-relaxed text-muted-foreground">
      {text}
    </pre>
  );
}

/* ------------------------------ form ------------------------------- */

export function FormBlock({
  data,
  submitLabel,
  onSubmit,
  busy,
}: {
  data: unknown;
  submitLabel: string;
  onSubmit: (values: Record<string, string>) => void;
  busy?: boolean;
}) {
  const fRaw = (data ?? {}) as Partial<FormData>;
  const f: FormData = { fields: Array.isArray(fRaw.fields) ? fRaw.fields : [], values: fRaw.values };
  const [values, setValues] = React.useState<Record<string, string>>(f.values ?? {});
  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit(values);
      }}
    >
      {f.fields.map((fl) => (
        <div key={fl.name}>
          <label className="mb-1.5 block text-[12.5px] font-medium">{fl.label}</label>
          {fl.type === 'textarea' ? (
            <Textarea
              rows={3}
              placeholder={fl.placeholder}
              value={values[fl.name] ?? ''}
              onChange={(e) => setValues((v) => ({ ...v, [fl.name]: e.target.value }))}
            />
          ) : fl.type === 'select' ? (
            <select
              className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-ring/40"
              value={values[fl.name] ?? ''}
              onChange={(e) => setValues((v) => ({ ...v, [fl.name]: e.target.value }))}
            >
              <option value="">Choose…</option>
              {fl.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          ) : (
            <Input
              type={fl.type === 'number' ? 'number' : 'text'}
              placeholder={fl.placeholder}
              value={values[fl.name] ?? ''}
              onChange={(e) => setValues((v) => ({ ...v, [fl.name]: e.target.value }))}
            />
          )}
        </div>
      ))}
      <Button type="submit" size="sm" disabled={busy}>
        {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
        {submitLabel}
      </Button>
    </form>
  );
}
