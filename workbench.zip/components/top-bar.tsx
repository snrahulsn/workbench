'use client';

import Link from 'next/link';
import { cn } from '@/lib/utils';

export function Brand({ className }: { className?: string }) {
  return (
    <Link href="/" className={cn('flex items-center gap-2 rounded-md px-1.5 py-1 transition-colors hover:bg-accent', className)}>
      <span className="grid h-[22px] w-[22px] place-items-center rounded bg-primary text-[11px] font-bold text-primary-foreground">W</span>
      <span className="text-sm font-semibold tracking-tight">Workbench</span>
      <span className="rounded border px-1.5 text-[10px] leading-[1.4] text-muted-foreground">Beta</span>
    </Link>
  );
}

export function TopBar({ children }: { children?: React.ReactNode }) {
  return (
    <header className="flex h-[52px] shrink-0 items-center gap-2.5 border-b bg-background px-3.5">
      <Brand />
      {children}
    </header>
  );
}

export function Avatar({ initials = 'RN' }: { initials?: string }) {
  return (
    <span className="grid h-7 w-7 place-items-center rounded-full border bg-muted text-[11.5px] font-semibold text-muted-foreground">
      {initials}
    </span>
  );
}
