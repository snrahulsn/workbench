# Screen blocks

A stage's screen is a list of blocks. A block never holds data — it names a `source`, which is
a key in the draft's data, and says how to draw whatever is there. Any stage can read any key,
whichever stage produced it.

Every block takes `title`, `description` and `hideWhenEmpty` (default `true`).

The shapes below are also generated into the assistant's operating rules from the manifest, so
it is told exactly what to write. Whatever it writes is then repaired where it can be —
missing ids, `label` where `name` was meant, a bare list where an object was expected — so a
screen does not break over a near miss.

---

## markdown

`source` → a string.

```json
{ "type": "markdown", "source": "brief", "title": "What you asked for" }
```

## key-values

`source` → `[{ label, value }]`, or a plain object.

## stat-grid

`source` → `[{ label, value, hint?, tone? }]` · `columns` 2–4.

`tone` is one of `success`, `warning`, `danger`, `info`, `violet`, `neutral`.

## entity-cards

`source` → `[{ id, name, subtitle?, bullets?: [string], tags?: [{ text, tone? }], initial?, tone? }]`

`selectable` makes the cards a picker; `selectionKey` names the shared selection so a matrix
elsewhere follows the same choice.

## item-list

`source` → `[{ id, name, description?, meta?: [string], tags?: [{ text, tone? }] }]`

`meta` entries are plain text columns, hidden on narrow screens. `tags` are chips.

## matrix

Two lists crossed: rows down, entities across, a switch in each cell.

`source` → `{ items: [ /* item shape */ ], enabled: { "<entityId>": ["itemId", …] } }`
`axisSource` → the key holding the entities (usually the same one an `entity-cards` block uses).

An entity missing from `enabled` means everything is on for it. Toggling writes straight to the
draft with no assistant turn; set `onToggleTool` to also call an application tool, which
receives `{ group, item, enabled }`.

## table

`source` → `{ columns: [{ key, label, align?, mono?, width? }], rows: [{ <key>: value }] }`

A cell is a string, a number, or `{ text, tone }` to draw a badge.

## gallery

`source` → `{ items: [{ id, title, caption?, badge?, kind?, watermark? }] }`

`kind` is `id`, `table` or `letter` and picks the placeholder drawing.

## steps

`source` → `[{ title, detail?, state: "done" | "running" | "waiting" }]`

A stage with a `submit` writes its progress here automatically if a step block points at one of
that stage's produced keys.

## mapping

`source` → `{ columns: [left, right], rows: [{ left, right, state?, tone? }] }`

A `null` right-hand side draws as not connected.

## code

`source` → a string, or an object which is shown formatted.

## form

`source` → `{ fields: [{ name, label, type, placeholder?, options?, required? }], values? }`
`submitTool` → the application tool called with the values. `submitLabel` → the button text.

Field types: `text`, `textarea`, `select`, `number`.
