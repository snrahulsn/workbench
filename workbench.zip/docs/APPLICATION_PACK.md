# Application package format

An application enters the workbench as a folder. Nothing about an application lives in the
workbench's code: the steps, the screens, the tools, the starting templates and the assistant's
operating rules all come from this folder.

Registration is deterministic. The same folder either passes every check or it does not, and
the reasons are listed on the Applications screen and by `npm run pack:validate`.

```
packs/<slug>/
  manifest.json     required  the journey, the screens, the tools, the submit sequence
  SKILLS.md         required  the assistant's operating rules
  README.md         required  documentation for whoever configures it next
  mcp.json          required  where the tool servers live
  templates/*.json  required  at least one must seed the deliverable step
```

---

## The checks registration runs

| Check | What it means |
|---|---|
| Required files present | All four files exist |
| Manifest is valid | `manifest.json` parses and matches the schema below |
| Tool servers configured | `mcp.json` parses and defines every server the manifest names |
| Operating rules complete | `SKILLS.md` has all five required headings |
| Documentation complete | `README.md` has all four required headings |
| Every referenced tool is allow-listed | Nothing in the journey calls a tool that is not in `tools` |
| Journey is internally consistent | Every screen's data has a producer; every prerequisite exists |
| Starting templates supplied | Templates parse, and at least one seeds the deliverable step |
| Tool servers answer | A live handshake finds every declared tool (can be skipped) |

---

## manifest.json

```jsonc
{
  "schemaVersion": 1,
  "slug": "lendcheck",                  // folder-safe, lower case
  "name": "LendCheck",
  "summary": "One sentence, in the language a business reader uses.",

  // Shared vocabulary. Used by "Map a process" to suggest where this
  // application fits someone's workflow. Plain words, not product names.
  "capabilities": ["document extraction", "identity verification"],
  "consumes": ["scanned documents"],
  "produces": ["validation report"],

  "agent": {
    "model": "…",                      // optional; omit to use the deployment default
    "maxTurnsPerMessage": 12,          // hard stop on a single reply
    "maxToolResultChars": 1500,
    "templateFirst": true,             // refuse to author a covered step from scratch
    "extraRules": ["…"]                // appended to the operating rules
  },

  "mcp": { "servers": ["lendcheck"] },  // names must exist in mcp.json

  // The complete set of application tools the assistant may call.
  // Anything not listed here is unreachable, whatever the server exposes.
  "tools": {
    "read":  ["list_checks", "get_report"],
    "write": ["create_programme", "run_cases"]
  },

  "primaryArtifactStage": "checks",    // the deliverable; template policy applies here

  "journey": [ /* stages, see below */ ]
}
```

### A stage

```jsonc
{
  "id": "checklist",                   // lower case, stable
  "name": "Checklist",                 // what the person sees
  "intent": "One line, written for the person doing the work.",

  "requires": ["checks"],              // stage ids that must have data first
  "produces": ["checklist", "setup_progress"],   // data keys this stage owns

  // Data the app loads itself when the stage opens, so no assistant turn
  // is spent on it. Results land in the `into` key.
  "fetch": [{ "tool": "get_report", "into": "report", "args": { "case_id": "2" } }],

  "blocks": [ /* screen blocks, see SCREEN_SCHEMA.md */ ],

  // The button that writes into the target application. The app runs
  // these in order — the assistant cannot trigger them.
  "submit": {
    "label": "Set this up in LendCheck",
    "hint": "Creates a sandbox copy.",
    "tools": [
      { "tool": "create_programme", "label": "Creating the programme",
        "argsFrom": { "name": "$.draft.name" } }
    ]
  },

  // Buttons under the screen.
  "actions": [
    { "id": "to-cases", "label": "Try it on sample cases", "variant": "primary",
      "kind": "prompt", "prompt": "Generate sample cases and run them through.",
      "requires": ["checklist"], "requiresSubmit": true }
  ]
}
```

**Action kinds**

| kind | Effect |
|---|---|
| `prompt` | Sends `prompt` to the assistant as if the person typed it |
| `tool` | Calls `tool` directly with `args`. No assistant turn |
| `advance` | Moves to the next step |

`requires` on an action lists **data keys**, not stage ids.

### Argument resolution

`argsFrom` and an action's `args` may hold literals, or a JSONPath expression starting with
`$.` evaluated against everything the draft holds plus `draft.id`, `draft.name`, `draft.seed`.

```json
{ "name": "$.draft.name", "checks": "$.checklist.items", "environment": "sandbox" }
```

---

## SKILLS.md

Given to the assistant verbatim on every turn. Must contain these headings:

| Heading | What belongs there |
|---|---|
| `Scope` | What this application is for, and what it is not |
| `Operating rules` | How to work: order, defaults, what to never do quietly |
| `Template policy` | Which templates exist and when each applies |
| `Refusals` | What to say no to, and what to offer instead |
| `Tool reference` | Each tool, one line on when to use it |

Write it in plain business language. It is read by the assistant, but it is also the clearest
statement of how the application should behave, so keep it readable by a person.

---

## README.md

For whoever configures this application next. Must contain:

`What this application does` · `Journey` · `Capabilities` · `Configuration`

---

## mcp.json

Standard Model Context Protocol server configuration.

```json
{
  "mcpServers": {
    "lendcheck": { "type": "stdio", "command": "node", "args": ["./server/index.mjs"] }
  }
}
```

`http` and `sse` servers take `url` and optional `headers`. Tool servers are expected to be
stateless: each call carries what it needs and holds nothing between calls.

---

## templates/

One JSON file per template. Templates are the point: a handful of them, each covering a slice
of the real case mix, should between them cover almost everything. The assistant is required to
adopt the closest one and revise it rather than write from scratch.

```jsonc
{
  "id": "salaried-mortgage",
  "name": "Salaried mortgage",
  "summary": "A home loan to someone on a payroll, secured on the property.",
  "matches": ["home loan", "salaried", "mortgage"],   // phrases that signal this template
  "coverage": 0.45,                                   // share of cases it is expected to cover
  "seeds": {                                          // keyed by stage id
    "borrowers": { "borrower_types": [ /* … */ ] },
    "checks":    { "checks": [ /* … */ ] }
  }
}
```

Aim for four or five, with the coverage figures adding to something close to one. If people are
routinely starting from nothing, the template set is wrong — that is the signal to add one.

---

## Validating before you register

```bash
npm run pack:validate -- packs/lendcheck
npm run pack:validate -- packs/lendcheck --no-probe   # skip contacting the tool servers
```

Exit code is 0 only when every required check passes.
