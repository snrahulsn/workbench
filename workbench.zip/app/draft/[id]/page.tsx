import { notFound } from 'next/navigation';
import { draftContext } from '@/lib/draft';
import { buildView } from '@/lib/view';
import { Workbench } from './workbench';

export const dynamic = 'force-dynamic';

export default async function DraftPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const ctx = draftContext(id);
  if (!ctx) notFound();

  const view = await buildView(ctx.app, ctx.draft);
  const prompts = ctx.manifest.journey.flatMap((s) =>
    s.actions.filter((a) => a.kind === 'prompt' && a.prompt).map((a) => ({ stageId: s.id, id: a.id, label: a.label, prompt: a.prompt! })),
  );

  return <Workbench initial={view} suggestedPrompts={prompts} />;
}
