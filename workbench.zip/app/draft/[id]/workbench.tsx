'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { ChevronDown, Copy, Lightbulb, Loader2, Lock, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { TopBar, Avatar } from '@/components/top-bar';
import { Screen } from '@/components/screens/screen';
import type { DraftView } from '@/lib/view';
import { STATUS_LABEL, type DraftStatus } from '@/lib/schema';
import { formatMoney, formatTokens } from '@/lib/format';
import { Conversation, StepRail, type Turn } from './conversation';

const statusVariant: Record<DraftStatus, 'info' | 'warning' | 'success' | 'neutral'> = {
  new: 'info', in_progress: 'warning', published: 'success', locked: 'neutral', archived: 'neutral',
};

export function Workbench({
  initial,
  suggestedPrompts,
}: {
  initial: DraftView;
  suggestedPrompts: { stageId: string; id: string; label: string; prompt: string }[];
}) {
  const router = useRouter();
  const [view, setView] = React.useState(initial);
  const [turns, setTurns] = React.useState<Turn[]>(
    initial.messages.map((m) => ({ kind: 'said', role: m.role, text: m.body })),
  );
  const [busy, setBusy] = React.useState(false);
  const [selections, setSelections] = React.useState<Record<string, string>>({});
  const [lifecycleOpen, setLifecycleOpen] = React.useState(false);

  const locked = view.draft.status === 'locked';
  const stage = view.stage;

  const refresh = React.useCallback(async () => {
    const res = await fetch(`/api/drafts/${view.draft.id}`, { cache: 'no-store' });
    if (res.ok) setView(await res.json());
  }, [view.draft.id]);

  /* --------------------------- conversation --------------------------- */

  const send = async (text: string) => {
    setTurns((t) => [...t, { kind: 'said', role: 'user', text }]);
    setBusy(true);
    let needsRefresh = false;

    try {
      const res = await fetch(`/api/drafts/${view.draft.id}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text }),
      });
      if (!res.ok || !res.body) throw new Error(await res.text());

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split('\n\n');
        buffer = parts.pop() ?? '';
        for (const part of parts) {
          const line = part.trim();
          if (!line.startsWith('data:')) continue;
          const ev = JSON.parse(line.slice(5)) as Record<string, unknown>;

          switch (ev.type) {
            case 'text':
              setTurns((t) => [...t, { kind: 'said', role: 'assistant', text: String(ev.text) }]);
              break;
            case 'tool_start':
              setTurns((t) => [...t, { kind: 'doing', id: String(ev.id), label: String(ev.label), state: 'running' }]);
              break;
            case 'tool_end':
              setTurns((t) =>
                t.map((x) =>
                  x.kind === 'doing' && x.id === ev.id
                    ? { ...x, state: ev.ok ? 'done' : 'failed' }
                    : x,
                ),
              );
              break;
            case 'stage_changed':
            case 'data_changed':
            case 'suggestion':
              needsRefresh = true;
              break;
            case 'error':
              setTurns((t) => [...t, { kind: 'said', role: 'assistant', text: String(ev.message) }]);
              break;
          }
        }
      }
    } catch (e) {
      setTurns((t) => [...t, { kind: 'said', role: 'assistant', text: e instanceof Error ? e.message : 'Something went wrong.' }]);
    } finally {
      setBusy(false);
      if (needsRefresh) await refresh();
      else await refreshUsage();
    }
  };

  const refreshUsage = async () => {
    const res = await fetch(`/api/drafts/${view.draft.id}`, { cache: 'no-store' });
    if (res.ok) {
      const next = (await res.json()) as DraftView;
      setView((v) => ({ ...v, usage: next.usage, draft: next.draft, suggestions: next.suggestions }));
    }
  };

  /* ------------------------------ screen ------------------------------ */

  const goToStep = async (index: number) => {
    await fetch(`/api/drafts/${view.draft.id}/stage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: 'goto', stageIndex: index }),
    });
    await refresh();
  };

  const onMatrixToggle = async (source: string, axisId: string, itemId: string, next: boolean) => {
    setView((v) => ({ ...v, data: optimisticToggle(v.data, source, axisId, itemId, next) }));
    await fetch(`/api/drafts/${view.draft.id}/stage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: 'matrix', source, axisId, itemId, enabled: next }),
    });
    await refreshUsage();
  };

  const onFormSubmit = async (tool: string, values: Record<string, string>) => {
    setBusy(true);
    await fetch(`/api/drafts/${view.draft.id}/stage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: 'form', tool, values }),
    });
    setBusy(false);
    await refresh();
  };

  const onSubmit = async () => {
    setBusy(true);
    const res = await fetch(`/api/drafts/${view.draft.id}/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stageId: stage.id }),
    });
    setBusy(false);
    if (!res.ok) {
      const j = await res.json().catch(() => ({ error: 'That did not go through.' }));
      setTurns((t) => [...t, { kind: 'said', role: 'assistant', text: j.error ?? 'That did not go through.' }]);
    }
    await refresh();
  };

  const onAction = async (actionId: string) => {
    const action = stage.actions.find((a) => a.id === actionId);
    if (!action) return;
    if (action.kind === 'prompt' && action.prompt) return send(action.prompt);
    if (action.kind === 'advance') {
      const i = view.steps.findIndex((s) => s.id === stage.id);
      return goToStep(Math.min(i + 1, view.steps.length - 1));
    }
    if (action.kind === 'tool' && action.tool) {
      setBusy(true);
      await fetch(`/api/drafts/${view.draft.id}/stage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind: 'form', tool: action.tool, values: action.args ?? {} }),
      });
      setBusy(false);
      await refresh();
    }
  };

  const setStatus = async (status: DraftStatus) => {
    await fetch(`/api/drafts/${view.draft.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    setLifecycleOpen(false);
    await refresh();
  };

  const duplicate = async () => {
    const res = await fetch(`/api/drafts/${view.draft.id}/duplicate`, { method: 'POST' });
    const j = await res.json();
    if (j.draft) router.push(`/draft/${j.draft.id}`);
  };

  const stagePrompts = suggestedPrompts.filter((p) => p.stageId === stage.id);

  return (
    <div className="flex h-full flex-col">
      <TopBar>
        <span className="h-5 w-px bg-border" />
        <span className="max-w-[300px] truncate text-[13.5px] font-medium">{view.draft.name}</span>
        <Badge variant={statusVariant[view.draft.status]}>{STATUS_LABEL[view.draft.status]}</Badge>
        <Button variant="ghost" size="icon-sm" onClick={() => setLifecycleOpen(true)} title="Status">
          <ChevronDown className="h-3.5 w-3.5" />
        </Button>

        <div className="flex-1" />

        <Popover>
          <PopoverTrigger asChild>
            <button className="flex h-[30px] items-center gap-1.5 rounded-md border border-transparent px-2.5 text-[12.5px] tabular text-muted-foreground transition-colors hover:border-border hover:bg-accent">
              <span className="h-[5px] w-[5px] rounded-full bg-success" />
              {formatTokens(view.usage.tokens)} tok
              <span className="text-border">·</span>
              <b className="font-semibold text-foreground">{formatMoney(view.usage.cost)}</b>
            </button>
          </PopoverTrigger>
          <PopoverContent>
            <div className="text-[12.5px] font-semibold">Draft spend</div>
            <div className="mb-3 text-[11.5px] text-muted-foreground">{view.draft.name}</div>
            {[
              ['Understanding', formatTokens(view.usage.detail.input)],
              ['Generation', formatTokens(view.usage.detail.output)],
              ['Reused context', formatTokens(view.usage.detail.cacheRead)],
              ['Other services', formatMoney(view.usage.detail.external)],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between py-1 text-[12.5px] tabular text-muted-foreground">
                <span>{k}</span><span className="font-medium text-foreground">{v}</span>
              </div>
            ))}
            <div className="mt-2 flex justify-between border-t pt-2.5 text-[12.5px] font-semibold tabular">
              <span>Total</span><span>{formatMoney(view.usage.cost)}</span>
            </div>
          </PopoverContent>
        </Popover>

        <Button variant="outline" size="sm" onClick={duplicate}><Copy className="h-3.5 w-3.5" />Duplicate</Button>
        <Button
          size="sm"
          disabled={locked || view.draft.status === 'published'}
          onClick={() => setStatus('published')}
        >
          {view.draft.status === 'published' ? 'Published' : locked ? <><Lock className="h-3.5 w-3.5" />Locked</> : 'Publish'}
        </Button>
        <Avatar />
      </TopBar>

      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[392px_1fr]">
        <Conversation
          turns={turns}
          busy={busy}
          locked={locked}
          prompts={stagePrompts}
          onSend={send}
        />

        <section className="flex min-w-0 flex-col bg-canvas">
          <StepRail steps={view.steps} current={view.stageIndex} applicationName={view.application.name} onGo={goToStep} />
          <div className="flex-1 overflow-y-auto px-6 pb-16 pt-6">
            <div className="mx-auto max-w-[960px]">
              {!!view.suggestions.length && (
                <div className="mb-3.5 space-y-2">
                  {view.suggestions.map((s) => (
                    <Card key={s.id} className="border-warning-border bg-warning-foreground">
                      <CardContent className="flex items-start gap-3 p-3.5">
                        <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
                        <div className="min-w-0 flex-1">
                          <div className="text-[13px] font-medium">{s.title}</div>
                          <div className="mt-0.5 text-[12.5px] leading-relaxed text-muted-foreground">{s.rationale}</div>
                        </div>
                        <div className="flex shrink-0 gap-1.5">
                          <Button size="xs" variant="outline" onClick={() => decide(view.draft.id, s.id, 'accepted', refresh)}>
                            Take it up
                          </Button>
                          <Button size="icon-sm" variant="ghost" onClick={() => decide(view.draft.id, s.id, 'dismissed', refresh)}>
                            <X className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              <Screen
                stage={stage}
                state={{ data: view.data, selections, busy, submitted: view.submitted, locked }}
                handlers={{
                  onSelect: (key, id) => setSelections((s) => ({ ...s, [key]: id })),
                  onMatrixToggle,
                  onAction,
                  onFormSubmit,
                  onSubmit,
                }}
              />
            </div>
          </div>
        </section>
      </div>

      <Dialog open={lifecycleOpen} onOpenChange={setLifecycleOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Draft status</DialogTitle>
            <DialogDescription>{view.draft.name}</DialogDescription>
          </DialogHeader>
          <div className="space-y-1">
            {(
              [
                ['new', 'created, nothing done yet'],
                ['in_progress', 'being worked on'],
                ['published', 'live in the application'],
                ['locked', 'read-only, spend frozen'],
                ['archived', 'hidden from the list'],
              ] as [DraftStatus, string][]
            ).map(([s, hint]) => (
              <button
                key={s}
                onClick={() => setStatus(s)}
                className="flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-left transition-colors hover:bg-accent"
              >
                <Badge variant={statusVariant[s]}>{STATUS_LABEL[s]}</Badge>
                <span className="text-[12.5px] text-muted-foreground">{hint}</span>
                {view.draft.status === s && <span className="ml-auto text-[12px] text-success">current</span>}
              </button>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={duplicate}>Duplicate</Button>
            <Button onClick={() => setLifecycleOpen(false)}>Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {busy && (
        <div className="pointer-events-none fixed bottom-5 left-1/2 z-50 -translate-x-1/2 rounded-md bg-primary px-3.5 py-2 text-[12.5px] text-primary-foreground shadow-lg">
          <span className="inline-flex items-center gap-2"><Loader2 className="h-3 w-3 animate-spin" />Working</span>
        </div>
      )}
    </div>
  );
}

async function decide(draftId: string, suggestionId: number, decision: 'accepted' | 'dismissed', done: () => Promise<void>) {
  await fetch(`/api/drafts/${draftId}/action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ suggestionId, decision }),
  });
  await done();
}

/** Keeps a switch responsive while the write lands. */
function optimisticToggle(
  data: Record<string, unknown>,
  source: string,
  axisId: string,
  itemId: string,
  next: boolean,
): Record<string, unknown> {
  const m = data[source] as { items?: { id: string }[]; enabled?: Record<string, string[]> } | undefined;
  if (!m?.items) return data;
  const all = m.items.map((i) => i.id);
  const current = m.enabled?.[axisId] ?? all;
  const updated = next ? Array.from(new Set([...current, itemId])) : current.filter((x) => x !== itemId);
  return { ...data, [source]: { ...m, enabled: { ...(m.enabled ?? {}), [axisId]: updated } } };
}

