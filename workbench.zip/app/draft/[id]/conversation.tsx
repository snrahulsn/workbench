'use client';

import * as React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Check, ChevronDown, Loader2, Send, Terminal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export type Turn =
  | { kind: 'said'; role: 'user' | 'assistant'; text: string }
  | { kind: 'doing'; id: string; label: string; state: 'running' | 'done' | 'failed'; note?: string };

export function Conversation({
  turns,
  busy,
  locked,
  prompts,
  onSend,
}: {
  turns: Turn[];
  busy: boolean;
  locked: boolean;
  prompts: { id: string; label: string; prompt: string }[];
  onSend: (text: string) => void;
}) {
  const [value, setValue] = React.useState('');
  const endRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [turns.length, busy]);

  const send = (text: string) => {
    const t = text.trim();
    if (!t || busy || locked) return;
    setValue('');
    onSend(t);
  };

  return (
    <aside className="flex min-w-0 flex-col border-r bg-background">
      <div className="flex h-[42px] shrink-0 items-center gap-2 border-b px-3">
        <Terminal className="h-3.5 w-3.5 text-muted-foreground" />
        <span className="text-[12.5px] font-medium">Session</span>
        <div className="flex-1" />
        <span className="flex items-center gap-1.5 text-[11.5px] text-muted-foreground">
          <Check className="h-3 w-3 text-success" strokeWidth={3} />Saved
        </span>
      </div>

      <div className="flex-1 space-y-3 overflow-y-auto px-3.5 py-4">
        {turns.length === 0 && (
          <p className="px-1 text-[13px] leading-relaxed text-muted-foreground">
            Say what you need. The screen beside this fills in as the work is done.
          </p>
        )}
        {turns.map((t, i) =>
          t.kind === 'said' ? (
            t.role === 'user' ? (
              <div key={i} className="ml-auto max-w-[88%] rounded-lg bg-muted px-3 py-2 text-[13.5px] leading-relaxed">
                {t.text}
              </div>
            ) : (
              <div key={i} className="text-[13.5px] leading-relaxed">
                <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground">
                  <span className="h-[5px] w-[5px] rounded-full bg-success" />Assistant
                </div>
                <div className="[&_code]:rounded [&_code]:bg-muted [&_code]:px-1 [&_p]:mb-1.5 [&_p:last-child]:mb-0 [&_strong]:font-semibold [&_ul]:list-disc [&_ul]:pl-5">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>{t.text}</ReactMarkdown>
                </div>
              </div>
            )
          ) : (
            <div key={i} className="flex items-center gap-2 rounded-md border bg-canvas px-2.5 py-1.5 text-[12.5px] text-muted-foreground">
              {t.state === 'running' ? (
                <Loader2 className="h-3 w-3 shrink-0 animate-spin" />
              ) : t.state === 'done' ? (
                <Check className="h-3 w-3 shrink-0 text-success" strokeWidth={3} />
              ) : (
                <span className="h-3 w-3 shrink-0 rounded-full border border-destructive/40" />
              )}
              <span className="truncate text-foreground">{t.label}</span>
            </div>
          ),
        )}
        {busy && !turns.some((t) => t.kind === 'doing' && t.state === 'running') && (
          <div className="flex items-center gap-2 text-[12.5px] text-muted-foreground">
            <Loader2 className="h-3 w-3 animate-spin" />Thinking
          </div>
        )}
        <div ref={endRef} />
      </div>

      <div className="shrink-0 border-t p-3">
        {!!prompts.length && !busy && !locked && (
          <div className="mb-2 flex flex-wrap gap-1.5">
            {prompts.slice(0, 3).map((p) => (
              <button
                key={p.id}
                onClick={() => send(p.prompt)}
                className="rounded-full border px-2.5 py-1 text-[12px] text-muted-foreground transition-colors hover:border-ring/60 hover:bg-accent hover:text-foreground"
              >
                {p.label}
              </button>
            ))}
          </div>
        )}
        <div className="rounded-lg border px-2.5 py-2 transition-shadow focus-within:shadow-sm">
          <textarea
            value={value}
            disabled={locked}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                send(value);
              }
            }}
            rows={2}
            placeholder={locked ? 'This draft is locked.' : 'Reply, or ask for a change'}
            className="w-full resize-none bg-transparent text-[13.5px] leading-relaxed outline-none placeholder:text-muted-foreground/70 disabled:cursor-not-allowed"
          />
          <div className="mt-1 flex items-center justify-end">
            <Button size="sm" disabled={busy || locked || !value.trim()} onClick={() => send(value)}>
              {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
              Send
            </Button>
          </div>
        </div>
      </div>
    </aside>
  );
}

export function StepRail({
  steps,
  current,
  applicationName,
  onGo,
}: {
  steps: { id: string; name: string; state: 'done' | 'current' | 'available' | 'ahead' }[];
  current: number;
  applicationName: string;
  onGo: (index: number) => void;
}) {
  return (
    <div className="flex h-[46px] shrink-0 items-center gap-0.5 overflow-x-auto border-b bg-background px-2.5 no-scrollbar">
      {steps.map((s, i) => (
        <button
          key={s.id}
          disabled={s.state === 'ahead'}
          onClick={() => onGo(i)}
          className={cn(
            'flex shrink-0 items-center gap-2 rounded-md px-2.5 py-1.5 text-[12.5px] font-medium transition-colors',
            i === current ? 'bg-accent text-foreground' : 'text-muted-foreground hover:bg-accent',
            s.state === 'ahead' && 'cursor-not-allowed opacity-40 hover:bg-transparent',
          )}
        >
          <span
            className={cn(
              'grid h-[17px] w-[17px] shrink-0 place-items-center rounded-full border text-[9.5px] font-semibold',
              s.state === 'done' ? 'border-success bg-success text-success-foreground' : i === current ? 'border-foreground text-foreground' : 'border-border text-muted-foreground',
            )}
          >
            {s.state === 'done' ? <Check className="h-2.5 w-2.5" strokeWidth={3.5} /> : i + 1}
          </span>
          {s.name}
        </button>
      ))}
      <span className="ml-auto hidden shrink-0 items-center gap-1.5 whitespace-nowrap pl-3 text-[11.5px] text-muted-foreground lg:flex">
        <ChevronDown className="h-3 w-3 rotate-[-90deg]" />
        Steps set by {applicationName}
      </span>
    </div>
  );
}
