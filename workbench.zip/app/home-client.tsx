'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowRight, Copy, FileText, Loader2, Lock, MoreHorizontal, Plus, Search, Settings2, Trash2, Workflow } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input, Textarea } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { TopBar, Avatar } from '@/components/top-bar';
import { STATUS_LABEL, type DraftStatus } from '@/lib/schema';
import { formatMoney, formatTokens, relativeTime } from '@/lib/format';
import { cn } from '@/lib/utils';

export type DraftRow = {
  id: string; name: string; status: DraftStatus; applicationName: string; stepName: string;
  done: number; total: number; updatedAt: string; tokens: number; cost: number;
};
export type AppOption = {
  slug: string; name: string; summary: string; steps: string[];
  templates: { id: string; name: string; summary: string; coverage: number }[];
};

const statusVariant: Record<DraftStatus, 'info' | 'warning' | 'success' | 'neutral'> = {
  new: 'info', in_progress: 'warning', published: 'success', locked: 'neutral', archived: 'neutral',
};

export function HomeClient({ drafts, applications }: { drafts: DraftRow[]; applications: AppOption[] }) {
  const router = useRouter();
  const [q, setQ] = React.useState('');
  const [tab, setTab] = React.useState<'drafts' | 'templates'>('drafts');
  const [open, setOpen] = React.useState(false);
  const [seed, setSeed] = React.useState('');
  const [appSlug, setAppSlug] = React.useState(applications[0]?.slug ?? '');
  const [name, setName] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const app = applications.find((a) => a.slug === appSlug);
  const filtered = drafts.filter((d) => d.name.toLowerCase().includes(q.toLowerCase()));

  const create = async () => {
    setBusy(true);
    setError(null);
    const res = await fetch('/api/drafts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name.trim() || 'Untitled draft', appSlug, seed }),
    });
    const json = await res.json();
    setBusy(false);
    if (!res.ok) return setError(json.error ?? 'Could not create the draft.');
    router.push(`/draft/${json.draft.id}`);
  };

  const openNew = () => {
    setName(seed.trim() ? seed.trim().split(/[.\n]/)[0].slice(0, 60) : '');
    setError(null);
    setOpen(true);
  };

  return (
    <div className="flex h-full flex-col">
      <TopBar>
        <div className="flex-1" />
        <Button variant="ghost" size="sm" asChild>
          <Link href="/map"><Workflow className="h-3.5 w-3.5" />Map a process</Link>
        </Button>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/applications"><Settings2 className="h-3.5 w-3.5" />Applications</Link>
        </Button>
        <Avatar />
      </TopBar>

      <main className="flex-1 overflow-y-auto bg-canvas">
        <div className="mx-auto max-w-[880px] px-6 pb-24 pt-16">
          <h1 className="text-center text-3xl font-semibold tracking-tight">What should we build?</h1>
          <p className="mb-7 mt-1.5 text-center text-sm text-muted-foreground">
            {applications.length
              ? 'Describe what you need, or carry on with a draft.'
              : 'Register an application to get started.'}
          </p>

          <div className="rounded-lg border bg-background shadow-sm transition-shadow focus-within:shadow-md">
            <Textarea
              value={seed}
              onChange={(e) => setSeed(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey && applications.length) {
                  e.preventDefault();
                  openNew();
                }
              }}
              placeholder={
                app ? `Describe what you want ${app.name} to do` : 'Register an application first'
              }
              className="min-h-[84px] resize-none border-0 px-4 pb-2 pt-4 text-[14.5px] shadow-none focus-visible:ring-0"
              disabled={!applications.length}
            />
            <div className="flex items-center gap-2 px-2.5 pb-2.5">
              <select
                value={appSlug}
                onChange={(e) => setAppSlug(e.target.value)}
                disabled={!applications.length}
                className="h-[30px] rounded-md border bg-background px-2.5 text-[12.5px] text-muted-foreground outline-none transition-colors hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring/40"
              >
                {applications.map((a) => <option key={a.slug} value={a.slug}>{a.name}</option>)}
                {!applications.length && <option>No applications</option>}
              </select>
              {app && (
                <span className="hidden truncate text-[11.5px] text-muted-foreground sm:block">
                  {app.steps.length} steps · {app.templates.length} templates
                </span>
              )}
              <div className="flex-1" />
              <Button size="sm" onClick={openNew} disabled={!applications.length}>
                Create draft <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>

          {!applications.length && (
            <div className="mt-4 rounded-md border bg-background px-4 py-3 text-[13px] text-muted-foreground">
              No applications are registered yet.{' '}
              <Link href="/applications" className="font-medium text-foreground underline underline-offset-2">
                Register one
              </Link>{' '}
              to begin.
            </div>
          )}

          <div className="mb-3 mt-9 flex items-center gap-4 border-b">
            {(['drafts', 'templates'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={cn(
                  '-mb-px border-b-2 pb-2.5 text-[13.5px] font-medium capitalize transition-colors',
                  tab === t ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground',
                )}
              >
                {t}
              </button>
            ))}
            <div className="flex-1" />
            {tab === 'drafts' && (
              <div className="mb-2 flex h-8 items-center gap-2 rounded-md border bg-background px-2.5">
                <Search className="h-3.5 w-3.5 text-muted-foreground" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search drafts"
                  className="w-40 bg-transparent text-[13px] outline-none placeholder:text-muted-foreground/70"
                />
              </div>
            )}
          </div>

          {tab === 'drafts' ? (
            <DraftTable rows={filtered} />
          ) : (
            <TemplateList applications={applications} onPick={(slug, seedText) => { setAppSlug(slug); setSeed(seedText); openNew(); }} />
          )}
        </div>
      </main>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Name this draft</DialogTitle>
            <DialogDescription>
              The conversation, the work and the spend all belong to this draft and pick up where you left off.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="mb-1.5 block text-[12.5px] font-medium">Draft name</label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Give it a name you will recognise" autoFocus />
            </div>
            <div>
              <label className="mb-1.5 block text-[12.5px] font-medium">Application</label>
              <select
                value={appSlug}
                onChange={(e) => setAppSlug(e.target.value)}
                className="h-9 w-full rounded-md border bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring/40"
              >
                {applications.map((a) => <option key={a.slug} value={a.slug}>{a.name}</option>)}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-[12.5px] font-medium">What you want</label>
              <Textarea rows={3} value={seed} onChange={(e) => setSeed(e.target.value)} />
            </div>
            {app && (
              <p className="rounded-md border bg-canvas px-3 py-2.5 text-[12.5px] leading-relaxed text-muted-foreground">
                {app.name} takes you through {app.steps.length} steps, starting at {app.steps[0]}. Access is inherited from {app.name}.
              </p>
            )}
            {error && <p className="text-[12.5px] text-destructive">{error}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={create} disabled={busy}>
              {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}Create draft
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function DraftTable({ rows }: { rows: DraftRow[] }) {
  const router = useRouter();
  const act = async (id: string, body: Record<string, unknown>, method = 'PATCH') => {
    await fetch(`/api/drafts/${id}`, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    router.refresh();
  };
  const duplicate = async (id: string) => {
    await fetch(`/api/drafts/${id}/duplicate`, { method: 'POST' });
    router.refresh();
  };

  if (!rows.length) {
    return (
      <div className="rounded-lg border bg-background py-12 text-center text-[13px] text-muted-foreground shadow-sm">
        No drafts yet.
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-lg border bg-background shadow-sm">
      <div className="grid grid-cols-[1fr_96px_150px_96px_112px_34px] items-center gap-3.5 border-b bg-canvas px-3.5 py-2.5 text-[11.5px] font-medium text-muted-foreground">
        <div>Draft</div><div>Status</div><div>Progress</div><div>Updated</div>
        <div className="text-right">Spend</div><div />
      </div>
      {rows.map((d) => (
        <div key={d.id} className="grid grid-cols-[1fr_96px_150px_96px_112px_34px] items-center gap-3.5 border-b px-3.5 py-2.5 last:border-b-0 hover:bg-canvas">
          <Link href={`/draft/${d.id}`} className="flex min-w-0 items-center gap-2.5">
            <span className="grid h-[30px] w-[30px] shrink-0 place-items-center rounded-md border bg-muted text-muted-foreground">
              {d.status === 'locked' ? <Lock className="h-3.5 w-3.5" /> : <FileText className="h-3.5 w-3.5" />}
            </span>
            <span className="min-w-0">
              <span className="block truncate text-[13.5px] font-medium">{d.name}</span>
              <span className="block truncate text-[11.5px] text-muted-foreground">
                {d.applicationName}{d.stepName ? ` · ${d.stepName}` : ''}
              </span>
            </span>
          </Link>
          <div><Badge variant={statusVariant[d.status]}>{STATUS_LABEL[d.status]}</Badge></div>
          <div>
            <div className="h-[5px] overflow-hidden rounded-full bg-muted">
              <div className="h-full rounded-full bg-primary" style={{ width: `${d.total ? (d.done / d.total) * 100 : 0}%` }} />
            </div>
            <div className="mt-1.5 text-[11px] text-muted-foreground">{d.done} of {d.total} steps</div>
          </div>
          <div className="text-[12.5px] text-muted-foreground">{relativeTime(d.updatedAt)}</div>
          <div className="text-right text-[12.5px] font-medium tabular">
            {formatMoney(d.cost)}
            <span className="block text-[11px] font-normal text-muted-foreground">{formatTokens(d.tokens)} tokens</span>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon-sm"><MoreHorizontal className="h-4 w-4" /></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => duplicate(d.id)}><Copy className="h-3.5 w-3.5" />Duplicate</DropdownMenuItem>
              <DropdownMenuItem onClick={() => act(d.id, { status: d.status === 'locked' ? 'in_progress' : 'locked' })}>
                <Lock className="h-3.5 w-3.5" />{d.status === 'locked' ? 'Unlock' : 'Lock'}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-destructive" onClick={() => act(d.id, { status: 'archived' })}>
                <Trash2 className="h-3.5 w-3.5" />Archive
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ))}
    </div>
  );
}

function TemplateList({
  applications,
  onPick,
}: {
  applications: AppOption[];
  onPick: (slug: string, seed: string) => void;
}) {
  const rows = applications.flatMap((a) => a.templates.map((t) => ({ ...t, app: a })));
  if (!rows.length) {
    return (
      <div className="rounded-lg border bg-background py-12 text-center text-[13px] text-muted-foreground shadow-sm">
        No templates yet. They come with the application.
      </div>
    );
  }
  return (
    <div className="overflow-hidden rounded-lg border bg-background shadow-sm">
      {rows.map((t) => (
        <button
          key={`${t.app.slug}-${t.id}`}
          onClick={() => onPick(t.app.slug, t.summary)}
          className="grid w-full grid-cols-[1fr_120px_34px] items-center gap-3.5 border-b px-3.5 py-2.5 text-left last:border-b-0 hover:bg-canvas"
        >
          <span className="flex min-w-0 items-center gap-2.5">
            <span className="grid h-[30px] w-[30px] shrink-0 place-items-center rounded-md border bg-muted text-muted-foreground">
              <Plus className="h-3.5 w-3.5" />
            </span>
            <span className="min-w-0">
              <span className="block truncate text-[13.5px] font-medium">{t.name}</span>
              <span className="block truncate text-[11.5px] text-muted-foreground">{t.app.name} · {t.summary}</span>
            </span>
          </span>
          <span className="text-[12px] text-muted-foreground">covers ~{Math.round(t.coverage * 100)}%</span>
          <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />
        </button>
      ))}
    </div>
  );
}

