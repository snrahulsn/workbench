import { listApplications, syncPacksFromDisk } from '@/lib/pack';
import { MapClient } from './client';

export const dynamic = 'force-dynamic';

export default async function MapPage() {
  syncPacksFromDisk();
  const apps = listApplications().map((a) => ({
    slug: a.slug,
    name: a.name,
    summary: a.summary,
    capabilities: a.manifest.capabilities,
  }));
  return <MapClient applications={apps} />;
}
