'use client';

import * as React from 'react';
import Link from 'next/link';
import { ArrowRight, Loader2, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge, Chip } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { TopBar, Avatar } from '@/components/top-bar';

type App = { slug: string; name: string; summary: string; capabilities: string[] };

type Suggestion = {
  id: string;
  text: string;
  gap: boolean;
  candidates: { slug: string; name: string; summary: string; matched: string[]; score: number }[];
};

export function MapClient({ applications }: { applications: App[] }) {
  const [steps, setSteps] = React.useState<string[]>(['', '', '']);
  const [busy, setBusy] = React.useState(false);
  const [result, setResult] = React.useState<{ suggestions: Suggestion[]; coverage: { covered: number; total: number } } | null>(null);

  const run = async () => {
    const filled = steps.map((s) => s.trim()).filter(Boolean);
    if (!filled.length) return;
    setBusy(true);
    const res = await fetch('/api/registry/suggest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ steps: filled.map((text) => ({ text })) }),
    });
    setResult(res.ok ? await res.json() : null);
    setBusy(false);
  };

  return (
    <div className="flex h-full flex-col">
      <TopBar>
        <span className="h-5 w-px bg-border" />
        <span className="text-[13.5px] font-medium">Map a process</span>
        <div className="flex-1" />
        <Avatar />
      </TopBar>

      <main className="flex-1 overflow-y-auto bg-canvas">
        <div className="mx-auto max-w-[880px] px-6 pb-24 pt-12">
          <h1 className="text-2xl font-semibold tracking-tight">Map a process</h1>
          <p className="mb-7 mt-1 max-w-[68ch] text-[13.5px] leading-relaxed text-muted-foreground">
            Write out the steps of something your organisation does today, one per line. Each step is
            matched against what the registered applications can do, so you can see which parts are
            already covered and which are not.
          </p>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Your process</CardTitle>
              <div className="flex-1" />
              <Button variant="outline" size="xs" onClick={() => setSteps((s) => [...s, ''])}>
                <Plus className="h-3 w-3" />Add a step
              </Button>
            </CardHeader>
            <CardContent className="space-y-2">
              {steps.map((s, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="w-5 shrink-0 text-[12px] tabular text-muted-foreground">{i + 1}</span>
                  <Input
                    value={s}
                    placeholder={
                      i === 0 ? 'e.g. Collect and check the applicant’s documents' : 'What happens next'
                    }
                    onChange={(e) => setSteps((all) => all.map((x, j) => (j === i ? e.target.value : x)))}
                  />
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    onClick={() => setSteps((all) => all.filter((_, j) => j !== i))}
                    disabled={steps.length <= 1}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))}
              <Button size="sm" onClick={run} disabled={busy}>
                {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}Find what fits
              </Button>
            </CardContent>
          </Card>

          {result && (
            <>
              <div className="mb-3 flex items-center gap-2 text-[13px] text-muted-foreground">
                <Badge variant={result.coverage.covered === result.coverage.total ? 'success' : 'warning'}>
                  {result.coverage.covered} of {result.coverage.total} covered
                </Badge>
                <span>Steps with nothing against them are where a new application would earn its place.</span>
              </div>
              <div className="space-y-2.5">
                {result.suggestions.map((s, i) => (
                  <Card key={s.id}>
                    <CardContent className="p-4">
                      <div className="mb-2.5 flex items-start gap-3">
                        <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full border text-[11px] font-semibold text-muted-foreground">
                          {i + 1}
                        </span>
                        <div className="min-w-0 flex-1 text-[13.5px]">{s.text}</div>
                        {s.gap && <Badge variant="warning">nothing yet</Badge>}
                      </div>
                      {!s.gap && (
                        <div className="space-y-1.5 pl-9">
                          {s.candidates.map((c) => (
                            <div key={c.slug} className="flex flex-wrap items-center gap-2 rounded-md border bg-canvas px-3 py-2">
                              <span className="text-[13px] font-medium">{c.name}</span>
                              <span className="text-[12px] text-muted-foreground">{c.summary.slice(0, 90)}</span>
                              <div className="flex flex-wrap gap-1">
                                {c.matched.map((m) => <Chip key={m} tone="info">{m}</Chip>)}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          )}

          <div className="mt-8">
            <h2 className="mb-3 text-[13px] font-semibold">What is available to match against</h2>
            <div className="space-y-2">
              {applications.map((a) => (
                <div key={a.slug} className="rounded-lg border bg-background p-3.5 shadow-sm">
                  <div className="mb-1.5 flex items-center gap-2">
                    <span className="text-[13.5px] font-medium">{a.name}</span>
                    <span className="truncate text-[12px] text-muted-foreground">{a.summary}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {a.capabilities.map((c) => <Chip key={c}>{c}</Chip>)}
                  </div>
                </div>
              ))}
              {!applications.length && (
                <div className="rounded-lg border bg-background py-10 text-center text-[13px] text-muted-foreground shadow-sm">
                  Nothing registered yet.{' '}
                  <Link href="/applications" className="font-medium text-foreground underline underline-offset-2">
                    Register an application
                  </Link>{' '}
                  first.
                </div>
              )}
            </div>
          </div>

          <div className="mt-6">
            <Button variant="outline" size="sm" asChild>
              <Link href="/">Back to drafts <ArrowRight className="h-3.5 w-3.5" /></Link>
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
