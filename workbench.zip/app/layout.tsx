import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Workbench',
  description: 'Configure an application by working through its journey.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="h-full overflow-hidden">{children}</body>
    </html>
  );
}
