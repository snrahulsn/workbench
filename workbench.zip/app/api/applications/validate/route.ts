import { NextResponse } from 'next/server';
import path from 'node:path';
import fs from 'node:fs';
import { PACKS_DIR, listPackDirs, validatePack } from '@/lib/pack';
import { probeTools } from '@/lib/mcp-client';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** Lists candidate pack directories that have not been registered yet. */
export async function GET() {
  const dirs = listPackDirs().map((d) => ({ dir: d, name: path.basename(d) }));
  return NextResponse.json({ candidates: dirs, packsDir: PACKS_DIR });
}

/**
 * Runs every registration check, including a live handshake with the
 * declared tool servers unless `probe` is false.
 */
export async function POST(req: Request) {
  const { dir, probe = true } = (await req.json()) as { dir?: string; probe?: boolean };
  if (!dir) return NextResponse.json({ error: 'A pack directory is required.' }, { status: 400 });

  const abs = path.isAbsolute(dir) ? dir : path.join(PACKS_DIR, dir);
  if (!fs.existsSync(abs)) {
    return NextResponse.json({ error: `Nothing found at ${abs}` }, { status: 404 });
  }

  const result = validatePack(abs);
  const checks = [...result.checks];

  if (probe && result.manifest && result.mcp) {
    const { found, failed } = await probeTools(result.mcp, result.manifest.mcp.servers);
    const available = new Set(found.flatMap((f) => f.tools));
    const declared = [...result.manifest.tools.read, ...result.manifest.tools.write];
    const items = [
      ...failed.map((f) => ({ ok: false, text: `${f.server}: ${f.error}` })),
      ...declared.map((t) => ({ ok: available.has(t), text: t })),
    ];
    checks.push({
      id: 'probe',
      label: 'Tool servers answer and expose every declared tool',
      required: true,
      ok: failed.length === 0 && declared.every((t) => available.has(t)),
      detail: failed.length
        ? `${failed.length} server(s) did not answer.`
        : `${available.size} tools found across ${found.length} server(s).`,
      items,
    });
  }

  const ok = checks.filter((c) => c.required).every((c) => c.ok);
  return NextResponse.json({
    dir: abs,
    ok,
    checks,
    summary: result.manifest
      ? {
          name: result.manifest.name,
          slug: result.manifest.slug,
          steps: result.manifest.journey.map((s) => s.name),
          capabilities: result.manifest.capabilities,
          templates: result.templates.map((t) => ({ id: t.id, name: t.name, coverage: t.coverage })),
        }
      : null,
  });
}
