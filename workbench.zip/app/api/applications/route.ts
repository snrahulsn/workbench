import { NextResponse } from 'next/server';
import path from 'node:path';
import { listApplications, registerPack, syncPacksFromDisk, PACKS_DIR } from '@/lib/pack';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  syncPacksFromDisk();
  const apps = listApplications().map((a) => ({
    slug: a.slug,
    name: a.name,
    summary: a.summary,
    capabilities: a.manifest.capabilities,
    steps: a.manifest.journey.length,
    templates: a.templates.length,
    tools: a.manifest.tools.read.length + a.manifest.tools.write.length,
    registeredAt: a.registeredAt,
  }));
  return NextResponse.json({ applications: apps });
}

export async function POST(req: Request) {
  const { dir } = (await req.json()) as { dir?: string };
  if (!dir) return NextResponse.json({ error: 'A pack directory is required.' }, { status: 400 });
  const abs = path.isAbsolute(dir) ? dir : path.join(PACKS_DIR, dir);
  const result = registerPack(abs);
  return NextResponse.json(result, { status: result.ok ? 200 : 422 });
}
