import { NextResponse } from 'next/server';
import { listApplications, syncPacksFromDisk } from '@/lib/pack';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Given the steps of a process someone has written down, suggests which
 * registered applications fit where. Matching is on the shared
 * capability vocabulary each pack declares, so a new application becomes
 * suggestable the moment it is registered.
 */
export async function POST(req: Request) {
  syncPacksFromDisk();
  const { steps } = (await req.json()) as { steps?: { id?: string; text: string }[] };
  if (!steps?.length) return NextResponse.json({ error: 'Describe the steps first.' }, { status: 400 });

  const apps = listApplications();
  const suggestions = steps.map((step, i) => {
    const words = tokens(step.text);
    const scored = apps
      .map((a) => {
        const vocab = [...a.manifest.capabilities, ...a.manifest.consumes, ...a.manifest.produces];
        const hits = vocab.filter((c) => overlap(words, tokens(c)));
        const score = hits.length / Math.max(1, vocab.length ** 0.5);
        return { slug: a.slug, name: a.name, summary: a.summary, matched: hits.slice(0, 4), score };
      })
      .filter((s) => s.matched.length > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);

    return {
      id: step.id ?? `step-${i + 1}`,
      text: step.text,
      candidates: scored,
      gap: scored.length === 0,
    };
  });

  const covered = suggestions.filter((s) => !s.gap).length;
  return NextResponse.json({
    suggestions,
    coverage: { covered, total: suggestions.length },
    vocabulary: Array.from(new Set(apps.flatMap((a) => a.manifest.capabilities))).sort(),
  });
}

const STOP = new Set([
  'the', 'a', 'an', 'and', 'or', 'of', 'to', 'for', 'in', 'on', 'with', 'from',
  'by', 'is', 'are', 'be', 'we', 'our', 'then', 'that', 'this', 'it', 'as', 'at',
]);

function tokens(s: string): string[] {
  return s
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length > 2 && !STOP.has(w))
    .map(stem);
}

function stem(w: string) {
  return w.replace(/(ing|ed|es|s)$/, '');
}

function overlap(a: string[], b: string[]) {
  return b.some((x) => a.includes(x));
}
