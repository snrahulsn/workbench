import { NextResponse } from 'next/server';
import { draftContext, getAllStageData, getStageData, setStageData, updateDraft } from '@/lib/draft';
import { callTool } from '@/lib/mcp-client';
import { flatten, resolveArgs } from '@/lib/view';
import type { MatrixData } from '@/components/screens/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

/**
 * Direct edits made on the screen. These never involve the assistant:
 * a switch flip is a database write, and optionally a call to the
 * application if the pack declared one.
 */
export async function POST(req: Request, { params }: Ctx) {
  const { id } = await params;
  const ctx = draftContext(id);
  if (!ctx) return NextResponse.json({ error: 'Draft not found.' }, { status: 404 });
  if (ctx.draft.status === 'locked') return NextResponse.json({ error: 'This draft is locked.' }, { status: 409 });

  const body = (await req.json()) as
    | { kind: 'goto'; stageIndex: number }
    | { kind: 'matrix'; source: string; axisId: string; itemId: string; enabled: boolean }
    | { kind: 'form'; tool: string; values: Record<string, string> };

  if (body.kind === 'goto') {
    const draft = updateDraft(id, { stageIndex: body.stageIndex });
    return NextResponse.json({ draft });
  }

  if (body.kind === 'matrix') {
    const owner = ctx.manifest.journey.find((s) => s.produces.includes(body.source));
    if (!owner) return NextResponse.json({ error: 'Nothing on this screen owns that.' }, { status: 400 });

    const bag = getStageData(id, owner.id);
    const matrix = (bag[body.source] ?? { items: [], enabled: {} }) as MatrixData;
    const all = matrix.items.map((i) => i.id);
    const current = matrix.enabled?.[body.axisId] ?? all;
    const next = body.enabled
      ? Array.from(new Set([...current, body.itemId]))
      : current.filter((x) => x !== body.itemId);

    matrix.enabled = { ...(matrix.enabled ?? {}), [body.axisId]: next };
    setStageData(id, owner.id, { ...bag, [body.source]: matrix });

    // A published draft that gets edited goes back to being worked on.
    if (ctx.draft.status === 'published') updateDraft(id, { status: 'in_progress' });

    // Optional write-through, if the pack asked for one.
    const block = ctx.manifest.journey
      .flatMap((s) => s.blocks)
      .find((b) => b.type === 'matrix' && b.source === body.source);
    if (block && block.type === 'matrix' && block.onToggleTool) {
      await callTool(ctx.app.mcp, ctx.manifest.mcp.servers, block.onToggleTool, {
        group: body.axisId,
        item: body.itemId,
        enabled: body.enabled,
      });
    }
    return NextResponse.json({ ok: true, enabled: next.length });
  }

  if (body.kind === 'form') {
    const allowed = new Set([...ctx.manifest.tools.read, ...ctx.manifest.tools.write]);
    if (!allowed.has(body.tool)) return NextResponse.json({ error: 'That action is not available.' }, { status: 403 });
    const context = flatten(getAllStageData(id));
    const args = resolveArgs(body.values, context, ctx.draft);
    const res = await callTool(ctx.app.mcp, ctx.manifest.mcp.servers, body.tool, args);
    if (!res.ok) return NextResponse.json({ error: res.error }, { status: 502 });
    return NextResponse.json({ ok: true, value: res.value });
  }

  return NextResponse.json({ error: 'Unknown request.' }, { status: 400 });
}
