import { NextResponse } from 'next/server';
import { deleteDraft, draftContext, updateDraft } from '@/lib/draft';
import { buildView } from '@/lib/view';
import { DRAFT_STATUSES, type DraftStatus } from '@/lib/schema';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Ctx) {
  const { id } = await params;
  const ctx = draftContext(id);
  if (!ctx) return NextResponse.json({ error: 'Draft not found.' }, { status: 404 });
  return NextResponse.json(await buildView(ctx.app, ctx.draft));
}

export async function PATCH(req: Request, { params }: Ctx) {
  const { id } = await params;
  const ctx = draftContext(id);
  if (!ctx) return NextResponse.json({ error: 'Draft not found.' }, { status: 404 });

  const body = (await req.json()) as { name?: string; status?: string; stageIndex?: number };
  if (body.status && !DRAFT_STATUSES.includes(body.status as DraftStatus)) {
    return NextResponse.json({ error: 'Unknown status.' }, { status: 400 });
  }
  if (ctx.draft.status === 'locked' && body.status !== 'in_progress' && body.status !== 'archived' && body.stageIndex === undefined) {
    return NextResponse.json({ error: 'This draft is locked.' }, { status: 409 });
  }

  const draft = updateDraft(id, {
    name: body.name,
    status: body.status as DraftStatus | undefined,
    stageIndex: body.stageIndex,
  });
  return NextResponse.json({ draft });
}

export async function DELETE(_req: Request, { params }: Ctx) {
  const { id } = await params;
  deleteDraft(id);
  return NextResponse.json({ ok: true });
}
