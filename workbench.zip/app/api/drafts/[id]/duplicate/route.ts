import { NextResponse } from 'next/server';
import { duplicateDraft } from '@/lib/draft';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const draft = duplicateDraft(id);
  if (!draft) return NextResponse.json({ error: 'Draft not found.' }, { status: 404 });
  return NextResponse.json({ draft });
}
