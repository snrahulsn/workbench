import { NextResponse } from 'next/server';
import { draftContext, getAllStageData, setStageData, updateDraft } from '@/lib/draft';
import { callTool } from '@/lib/mcp-client';
import { flatten, markSubmitted, resolveArgs } from '@/lib/view';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

/**
 * Writes into the target application. Runs the pack's declared tools in
 * order, from the app rather than the assistant, so the sequence is the
 * same every time and the person pressed the button for it.
 */
export async function POST(req: Request, { params }: Ctx) {
  const { id } = await params;
  const ctx = draftContext(id);
  if (!ctx) return NextResponse.json({ error: 'Draft not found.' }, { status: 404 });
  if (ctx.draft.status === 'locked') return NextResponse.json({ error: 'This draft is locked.' }, { status: 409 });

  const { stageId } = (await req.json()) as { stageId: string };
  const stage = ctx.manifest.journey.find((s) => s.id === stageId);
  if (!stage?.submit) return NextResponse.json({ error: 'This step has nothing to submit.' }, { status: 400 });

  const all = getAllStageData(id);
  const context = flatten(all);
  const allowed = new Set([...ctx.manifest.tools.read, ...ctx.manifest.tools.write]);

  const progress: { title: string; detail?: string; state: 'done' | 'running' | 'waiting' }[] =
    stage.submit.tools.map((t) => ({ title: t.label, state: 'waiting' as const }));

  const writeProgress = () => {
    const bag = getAllStageData(id)[stageId] ?? {};
    setStageData(id, stageId, { ...bag, setup_progress: progress });
  };
  writeProgress();

  for (let i = 0; i < stage.submit.tools.length; i++) {
    const t = stage.submit.tools[i];
    if (!allowed.has(t.tool)) {
      progress[i] = { ...progress[i], state: 'waiting', detail: 'Not available.' };
      writeProgress();
      return NextResponse.json({ error: `"${t.label}" is not available for this application.` }, { status: 403 });
    }
    progress[i] = { ...progress[i], state: 'running' };
    writeProgress();

    const args = resolveArgs(t.argsFrom as Record<string, unknown>, context, ctx.draft);
    const res = await callTool(ctx.app.mcp, ctx.manifest.mcp.servers, t.tool, args);
    if (!res.ok) {
      progress[i] = { ...progress[i], state: 'waiting', detail: res.error };
      writeProgress();
      return NextResponse.json({ error: res.error, at: t.label }, { status: 502 });
    }
    progress[i] = { ...progress[i], state: 'done', detail: summarise(res.value) };
    writeProgress();
  }

  markSubmitted(id, stageId, getAllStageData(id));
  const bag = getAllStageData(id)[stageId] ?? {};
  setStageData(id, stageId, { ...bag, setup_progress: progress });
  updateDraft(id, { status: 'in_progress' });

  return NextResponse.json({ ok: true, progress });
}

function summarise(v: unknown): string | undefined {
  if (typeof v === 'string') return v.slice(0, 120);
  if (v && typeof v === 'object') {
    const o = v as Record<string, unknown>;
    const parts = Object.entries(o)
      .filter(([, val]) => typeof val === 'string' || typeof val === 'number')
      .slice(0, 3)
      .map(([k, val]) => `${k} ${val}`);
    return parts.join(' · ') || undefined;
  }
  return undefined;
}
