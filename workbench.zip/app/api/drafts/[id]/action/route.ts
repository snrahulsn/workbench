import { NextResponse } from 'next/server';
import { draftContext, resolveSuggestion } from '@/lib/draft';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** Accepting or dismissing something the assistant raised. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!draftContext(id)) return NextResponse.json({ error: 'Draft not found.' }, { status: 404 });
  const { suggestionId, decision } = (await req.json()) as {
    suggestionId?: number;
    decision?: 'accepted' | 'dismissed';
  };
  if (!suggestionId || !decision) return NextResponse.json({ error: 'Nothing to decide on.' }, { status: 400 });
  resolveSuggestion(suggestionId, decision);
  return NextResponse.json({ ok: true });
}
