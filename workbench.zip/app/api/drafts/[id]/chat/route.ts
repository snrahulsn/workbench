import { addMessage, addUsage, draftContext, getAllStageData, updateDraft } from '@/lib/draft';
import { agent } from '@/lib/agent';
import { buildRules } from '@/lib/agent/rules';
import { buildWorkbenchServer, WORKBENCH_TOOL_NAMES } from '@/lib/agent/workbench-tools';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 300;

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, { params }: Ctx) {
  const { id } = await params;
  const ctx = draftContext(id);
  if (!ctx) return new Response('Draft not found.', { status: 404 });
  if (ctx.draft.status === 'locked') return new Response('This draft is locked.', { status: 409 });

  const { message } = (await req.json()) as { message?: string };
  const prompt = (message ?? '').trim();
  if (!prompt) return new Response('Nothing to send.', { status: 400 });

  addMessage(id, 'user', prompt);

  const { app, manifest } = ctx;
  const all = getAllStageData(id);
  const rules = buildRules(app, ctx.draft, all);

  // Only the application's declared tools, plus the workbench's own.
  const appTools = [...manifest.tools.read, ...manifest.tools.write].flatMap((t) =>
    manifest.mcp.servers.map((s) => `mcp__${s}__${t}`),
  );
  const allowedTools = [...WORKBENCH_TOOL_NAMES, ...appTools];

  const toolServers: Record<string, unknown> = {};
  for (const name of manifest.mcp.servers) {
    const cfg = app.mcp.mcpServers[name];
    if (cfg) toolServers[name] = cfg;
  }

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: unknown) => controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));
      let assistantText = '';

      try {
        for await (const ev of agent.run({
          prompt,
          rules,
          allowedTools,
          toolServers,
          localServer: buildWorkbenchServer(ctx.draft, app),
          sessionId: ctx.draft.sessionId,
          model: manifest.agent.model,
          maxTurns: manifest.agent.maxTurnsPerMessage,
        })) {
          switch (ev.type) {
            case 'session':
              if (ev.sessionId && ev.sessionId !== ctx.draft.sessionId) {
                updateDraft(id, { sessionId: ev.sessionId });
              }
              break;
            case 'text':
              assistantText += (assistantText ? '\n\n' : '') + ev.text;
              send(ev);
              break;
            case 'usage':
              addUsage(id, { input: ev.input, output: ev.output, cacheRead: ev.cacheRead, cacheWrite: ev.cacheWrite });
              send(ev);
              break;
            default:
              send(ev);
          }
        }
      } catch (e) {
        send({ type: 'error', message: e instanceof Error ? e.message : 'Something went wrong.' });
      } finally {
        if (assistantText.trim()) addMessage(id, 'assistant', assistantText.trim());
        send({ type: 'end' });
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
    },
  });
}
