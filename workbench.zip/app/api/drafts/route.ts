import { NextResponse } from 'next/server';
import { createDraft, getAllStageData, getUsage, listDrafts, setStageData, stageComplete } from '@/lib/draft';
import { getApplication, listApplications } from '@/lib/pack';
import { costOf } from '@/lib/cost';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const apps = Object.fromEntries(listApplications().map((a) => [a.slug, a]));
  const drafts = listDrafts().map((d) => {
    const app = apps[d.appSlug];
    const all = getAllStageData(d.id);
    const total = app?.manifest.journey.length ?? 0;
    const done = app ? app.manifest.journey.filter((s) => stageComplete(app.manifest, all, s.id)).length : 0;
    const usage = getUsage(d.id);
    return {
      ...d,
      applicationName: app?.name ?? d.appSlug,
      stepName: app?.manifest.journey[Math.min(d.stageIndex, total - 1)]?.name ?? '',
      progress: { done, total },
      usage: { tokens: usage.input + usage.output, cost: costOf(usage) },
    };
  });
  return NextResponse.json({ drafts });
}

export async function POST(req: Request) {
  const body = (await req.json()) as { name?: string; appSlug?: string; seed?: string };
  if (!body.name?.trim()) return NextResponse.json({ error: 'A name is required.' }, { status: 400 });
  if (!body.appSlug) return NextResponse.json({ error: 'An application is required.' }, { status: 400 });
  if (!getApplication(body.appSlug)) return NextResponse.json({ error: 'That application is not registered.' }, { status: 404 });

  const app = getApplication(body.appSlug)!;
  const seed = (body.seed ?? '').trim();
  const draft = createDraft({ name: body.name.trim(), appSlug: body.appSlug, seed });

  // The first step is filled in by the app, not by an assistant turn: it
  // is just what the person typed, plus what they gave us to read.
  const first = app.manifest.journey[0];
  const [request, sources] = first.produces;
  if (request) {
    setStageData(draft.id, first.id, {
      [request]: seed || 'Not stated yet.',
      ...(sources ? { [sources]: [{ label: 'Started from', value: seed ? 'What you typed' : 'An empty brief' }] } : {}),
    });
  }

  return NextResponse.json({ draft });
}
