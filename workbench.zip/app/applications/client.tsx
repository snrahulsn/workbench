'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { AlertCircle, Check, ChevronRight, Loader2, Package, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge, Chip } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { TopBar, Avatar } from '@/components/top-bar';
import { cn } from '@/lib/utils';

type Registered = {
  slug: string; name: string; summary: string; capabilities: string[];
  steps: string[]; templates: number; tools: number; packPath: string;
};
type Candidate = { dir: string; name: string };

type Check = { id: string; label: string; required: boolean; ok: boolean; detail: string; items?: { ok: boolean; text: string }[] };
type Result = {
  ok: boolean;
  dir: string;
  checks: Check[];
  summary: { name: string; slug: string; steps: string[]; capabilities: string[]; templates: { id: string; name: string; coverage: number }[] } | null;
};

export function ApplicationsClient({
  registered,
  candidates,
  packsDir,
}: {
  registered: Registered[];
  candidates: Candidate[];
  packsDir: string;
}) {
  const router = useRouter();
  const [dir, setDir] = React.useState(candidates[0]?.dir ?? '');
  const [probe, setProbe] = React.useState(true);
  const [checking, setChecking] = React.useState(false);
  const [registering, setRegistering] = React.useState(false);
  const [result, setResult] = React.useState<Result | null>(null);

  const registeredPaths = new Set(registered.map((r) => r.packPath));

  const check = async () => {
    setChecking(true);
    setResult(null);
    const res = await fetch('/api/applications/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dir, probe }),
    });
    const json = await res.json();
    setChecking(false);
    if (!res.ok) {
      setResult({ ok: false, dir, checks: [{ id: 'files', label: 'Package found', required: true, ok: false, detail: json.error }], summary: null });
      return;
    }
    setResult(json);
  };

  const register = async () => {
    setRegistering(true);
    await fetch('/api/applications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dir }),
    });
    setRegistering(false);
    setResult(null);
    router.refresh();
  };

  return (
    <div className="flex h-full flex-col">
      <TopBar>
        <span className="h-5 w-px bg-border" />
        <span className="text-[13.5px] font-medium">Applications</span>
        <div className="flex-1" />
        <Avatar />
      </TopBar>

      <main className="flex-1 overflow-y-auto bg-canvas">
        <div className="mx-auto max-w-[880px] px-6 pb-24 pt-12">
          <h1 className="text-2xl font-semibold tracking-tight">Applications</h1>
          <p className="mb-7 mt-1 max-w-[68ch] text-[13.5px] leading-relaxed text-muted-foreground">
            An application brings its own journey, its own starting templates and its own tools. Everything
            the workbench shows and does comes from the package you register here.
          </p>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Register an application</CardTitle>
              <div className="flex-1" />
              <span className="text-xs text-muted-foreground">Every check must pass</span>
            </CardHeader>
            <CardContent className="space-y-3.5">
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={dir}
                  onChange={(e) => { setDir(e.target.value); setResult(null); }}
                  className="h-9 min-w-[240px] flex-1 rounded-md border bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring/40"
                >
                  {!candidates.length && <option value="">Nothing found in {packsDir}</option>}
                  {candidates.map((c) => (
                    <option key={c.dir} value={c.dir}>
                      {c.name}{registeredPaths.has(c.dir) ? ' — registered' : ''}
                    </option>
                  ))}
                </select>
                <Input
                  value={dir}
                  onChange={(e) => { setDir(e.target.value); setResult(null); }}
                  placeholder="or type a path"
                  className="min-w-[200px] flex-1 font-mono text-[12px]"
                />
                <label className="flex items-center gap-2 text-[12.5px] text-muted-foreground">
                  <input type="checkbox" checked={probe} onChange={(e) => setProbe(e.target.checked)} className="h-3.5 w-3.5 accent-[hsl(var(--primary))]" />
                  Contact the tool servers
                </label>
                <Button size="sm" onClick={check} disabled={!dir || checking}>
                  {checking && <Loader2 className="h-3.5 w-3.5 animate-spin" />}Run checks
                </Button>
              </div>

              {result && (
                <div className="space-y-2 rounded-md border bg-canvas p-3">
                  {result.checks.map((c) => <CheckRow key={c.id} check={c} />)}
                  <div className="flex items-center gap-3 border-t pt-3">
                    {result.ok ? (
                      <>
                        <span className="text-[12.5px] text-success">Everything passed.</span>
                        <div className="flex-1" />
                        <Button size="sm" onClick={register} disabled={registering}>
                          {registering && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                          Register {result.summary?.name}
                        </Button>
                      </>
                    ) : (
                      <span className="text-[12.5px] text-muted-foreground">
                        Fix what is marked above, then run the checks again.
                      </span>
                    )}
                  </div>
                  {result.ok && result.summary && (
                    <div className="border-t pt-3 text-[12.5px] text-muted-foreground">
                      <div className="mb-1.5">
                        Journey: {result.summary.steps.join(' → ')}
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {result.summary.capabilities.map((c) => <Chip key={c}>{c}</Chip>)}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <h2 className="mb-3 text-[13px] font-semibold">Registered</h2>
          {!registered.length ? (
            <div className="rounded-lg border bg-background py-12 text-center text-[13px] text-muted-foreground shadow-sm">
              Nothing registered yet.
            </div>
          ) : (
            <div className="space-y-2.5">
              {registered.map((a) => (
                <Card key={a.slug}>
                  <CardContent className="p-4">
                    <div className="mb-2 flex items-start gap-3">
                      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-md border bg-muted text-muted-foreground">
                        <Package className="h-4 w-4" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="text-[13.5px] font-medium">{a.name}</div>
                        <div className="mt-0.5 text-[12.5px] leading-relaxed text-muted-foreground">{a.summary}</div>
                      </div>
                      <Badge variant="success">ready</Badge>
                    </div>
                    <div className="mb-2.5 flex flex-wrap items-center gap-1 text-[12px] text-muted-foreground">
                      {a.steps.map((s, i) => (
                        <React.Fragment key={s}>
                          {i > 0 && <ChevronRight className="h-3 w-3 opacity-50" />}
                          <span>{s}</span>
                        </React.Fragment>
                      ))}
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      {a.capabilities.map((c) => <Chip key={c}>{c}</Chip>)}
                      <span className="ml-auto text-[11.5px] text-muted-foreground">
                        {a.templates} templates · {a.tools} tools
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          <div className="mt-8 rounded-md border bg-background px-4 py-3 text-[12.5px] leading-relaxed text-muted-foreground">
            <Plus className="mr-1.5 inline h-3.5 w-3.5" />
            A package is a folder holding <code className="rounded bg-muted px-1 font-mono">manifest.json</code>,{' '}
            <code className="rounded bg-muted px-1 font-mono">SKILLS.md</code>,{' '}
            <code className="rounded bg-muted px-1 font-mono">README.md</code>,{' '}
            <code className="rounded bg-muted px-1 font-mono">mcp.json</code> and a{' '}
            <code className="rounded bg-muted px-1 font-mono">templates/</code> folder. The format is written up in
            docs/APPLICATION_PACK.md.
          </div>
        </div>
      </main>
    </div>
  );
}

function CheckRow({ check }: { check: Check }) {
  const [open, setOpen] = React.useState(!check.ok);
  return (
    <div className="rounded-md border bg-background">
      <button onClick={() => setOpen((o) => !o)} className="flex w-full items-center gap-2.5 px-3 py-2 text-left">
        {check.ok ? (
          <span className="grid h-4 w-4 shrink-0 place-items-center rounded-full bg-success text-success-foreground">
            <Check className="h-2.5 w-2.5" strokeWidth={3.5} />
          </span>
        ) : (
          <AlertCircle className="h-4 w-4 shrink-0 text-destructive" />
        )}
        <span className="text-[12.5px] font-medium">{check.label}</span>
        <span className="flex-1 truncate text-[11.5px] text-muted-foreground">{check.detail}</span>
        <ChevronRight className={cn('h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform', open && 'rotate-90')} />
      </button>
      {open && !!check.items?.length && (
        <div className="grid gap-1 border-t px-3 py-2 sm:grid-cols-2">
          {check.items.map((it, i) => (
            <div key={i} className={cn('flex items-start gap-1.5 text-[11.5px]', it.ok ? 'text-muted-foreground' : 'text-destructive')}>
              <span className="mt-[3px]">{it.ok ? '·' : '×'}</span>
              <span className="min-w-0 break-words">{it.text}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
