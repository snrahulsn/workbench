import { listApplications, listPackDirs, syncPacksFromDisk, PACKS_DIR } from '@/lib/pack';
import path from 'node:path';
import { ApplicationsClient } from './client';

export const dynamic = 'force-dynamic';

export default async function ApplicationsPage() {
  syncPacksFromDisk();
  const registered = listApplications().map((a) => ({
    slug: a.slug,
    name: a.name,
    summary: a.summary,
    capabilities: a.manifest.capabilities,
    steps: a.manifest.journey.map((s) => s.name),
    templates: a.templates.length,
    tools: a.manifest.tools.read.length + a.manifest.tools.write.length,
    packPath: a.packPath,
  }));

  const candidates = listPackDirs().map((d) => ({ dir: d, name: path.basename(d) }));

  return <ApplicationsClient registered={registered} candidates={candidates} packsDir={PACKS_DIR} />;
}
