import { syncPacksFromDisk, listApplications } from '@/lib/pack';
import { getAllStageData, getUsage, listDrafts, stageComplete } from '@/lib/draft';
import { costOf } from '@/lib/cost';
import { HomeClient, type DraftRow, type AppOption } from './home-client';

export const dynamic = 'force-dynamic';

export default async function Home() {
  syncPacksFromDisk();
  const apps = listApplications();
  const bySlug = Object.fromEntries(apps.map((a) => [a.slug, a]));

  const drafts: DraftRow[] = listDrafts().map((d) => {
    const app = bySlug[d.appSlug];
    const all = getAllStageData(d.id);
    const total = app?.manifest.journey.length ?? 0;
    const done = app ? app.manifest.journey.filter((s) => stageComplete(app.manifest, all, s.id)).length : 0;
    const usage = getUsage(d.id);
    const idx = Math.min(d.stageIndex, Math.max(0, total - 1));
    return {
      id: d.id,
      name: d.name,
      status: d.status,
      applicationName: app?.name ?? d.appSlug,
      stepName: app?.manifest.journey[idx]?.name ?? '',
      done,
      total,
      updatedAt: d.updatedAt,
      tokens: usage.input + usage.output,
      cost: costOf(usage),
    };
  });

  const options: AppOption[] = apps.map((a) => ({
    slug: a.slug,
    name: a.name,
    summary: a.summary,
    steps: a.manifest.journey.map((s) => s.name),
    templates: a.templates.map((t) => ({ id: t.id, name: t.name, summary: t.summary, coverage: t.coverage })),
  }));

  return <HomeClient drafts={drafts} applications={options} />;
}
