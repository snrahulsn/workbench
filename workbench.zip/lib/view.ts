import { JSONPath } from 'jsonpath-plus';
import { costOf } from './cost';
import {
  furthestReachable, getAllStageData, getUsage, listMessages, listSuggestions,
  setStageData, stageComplete, type Draft, type StageBag,
} from './draft';
import { callTool } from './mcp-client';
import type { Application } from './pack';

/**
 * Everything a workbench screen needs, assembled on the server. The
 * client receives one object and draws it; nothing here passes through
 * the conversation.
 */
export type DraftView = {
  draft: Draft;
  application: { slug: string; name: string };
  steps: { id: string; name: string; state: 'done' | 'current' | 'available' | 'ahead' }[];
  stage: Application['manifest']['journey'][number];
  stageIndex: number;
  data: Record<string, unknown>;
  submitted: boolean;
  messages: { id: number; role: 'user' | 'assistant'; kind: string; body: string }[];
  suggestions: { id: number; title: string; rationale: string; impact: string }[];
  usage: { tokens: number; cost: number; detail: Record<string, number> };
};

const SUBMIT_FLAG = '__submitted';

export function isSubmitted(all: Record<string, StageBag>, stageId: string) {
  return !!all[stageId]?.[SUBMIT_FLAG];
}

export function markSubmitted(draftId: string, stageId: string, all: Record<string, StageBag>) {
  setStageData(draftId, stageId, { ...(all[stageId] ?? {}), [SUBMIT_FLAG]: true });
}

/** Flattens every step's bag into one lookup, since block sources are global keys. */
export function flatten(all: Record<string, StageBag>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const bag of Object.values(all)) {
    for (const [k, v] of Object.entries(bag)) {
      if (k.startsWith('__')) continue;
      out[k] = v;
    }
  }
  return out;
}

/**
 * Runs a step's declared fetches. The app does this itself so screens
 * load without spending an assistant turn.
 */
export async function runStageFetches(app: Application, draft: Draft, stageId: string) {
  const stage = app.manifest.journey.find((s) => s.id === stageId);
  if (!stage?.fetch.length) return;
  const all = getAllStageData(draft.id);
  const bag = all[stageId] ?? {};
  const context = flatten(all);
  const updates: StageBag = {};

  for (const f of stage.fetch) {
    if (bag[f.into] !== undefined) continue; // already loaded
    const args = resolveArgs(f.args as Record<string, unknown>, context, draft);
    const res = await callTool(app.mcp, app.manifest.mcp.servers, f.tool, args);
    if (res.ok) updates[f.into] = res.value;
  }
  if (Object.keys(updates).length) setStageData(draft.id, stageId, { ...bag, ...updates });
}

/**
 * Argument values may be literals, or `$.jsonpath` expressions read
 * against everything the draft holds. Keeps packs declarative.
 */
export function resolveArgs(
  spec: Record<string, unknown>,
  context: Record<string, unknown>,
  draft: Draft,
): Record<string, unknown> {
  const scope = { ...context, draft: { id: draft.id, name: draft.name, seed: draft.seed } };
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(spec)) {
    if (typeof v === 'string' && v.startsWith('$.')) {
      const hit = JSONPath({ path: v, json: scope, wrap: false });
      out[k] = hit;
    } else {
      out[k] = v;
    }
  }
  return out;
}

export async function buildView(app: Application, draft: Draft): Promise<DraftView> {
  const manifest = app.manifest;
  const clamped = Math.min(Math.max(draft.stageIndex, 0), manifest.journey.length - 1);
  const stage = manifest.journey[clamped];

  await runStageFetches(app, draft, stage.id);

  const all = getAllStageData(draft.id);
  const reachable = Math.max(furthestReachable(manifest, all), clamped);
  const usage = getUsage(draft.id);

  return {
    draft: { ...draft, stageIndex: clamped },
    application: { slug: app.slug, name: app.name },
    steps: manifest.journey.map((s, i) => {
      const done = stageComplete(manifest, all, s.id);
      const state = i === clamped ? 'current' : done ? 'done' : i <= reachable ? 'available' : 'ahead';
      return { id: s.id, name: s.name, state: state as 'done' | 'current' | 'available' | 'ahead' };
    }),
    stage,
    stageIndex: clamped,
    data: flatten(all),
    submitted: isSubmitted(all, stage.id),
    messages: listMessages(draft.id).map((m) => ({ id: m.id, role: m.role, kind: m.kind, body: m.body })),
    suggestions: listSuggestions(draft.id),
    usage: {
      tokens: usage.input + usage.output,
      cost: costOf(usage),
      detail: {
        input: usage.input,
        output: usage.output,
        cacheRead: usage.cacheRead,
        cacheWrite: usage.cacheWrite,
        external: usage.externalInr,
      },
    },
  };
}
