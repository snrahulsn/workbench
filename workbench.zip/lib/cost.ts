import fs from 'node:fs';
import path from 'node:path';
import type { Usage } from './draft';

/**
 * Pricing lives in config/pricing.json so it can be corrected without
 * a code change. Values are rupees per million tokens.
 */
type Pricing = {
  currency: string;
  perMillion: { input: number; output: number; cacheRead: number; cacheWrite: number };
};

const DEFAULT: Pricing = {
  currency: 'INR',
  perMillion: { input: 262, output: 1310, cacheRead: 26.2, cacheWrite: 327.5 },
};

let cached: Pricing | null = null;

export function pricing(): Pricing {
  if (cached) return cached;
  const p = path.join(process.cwd(), 'config', 'pricing.json');
  try {
    cached = { ...DEFAULT, ...(JSON.parse(fs.readFileSync(p, 'utf8')) as Pricing) };
  } catch {
    cached = DEFAULT;
  }
  return cached;
}

export function costOf(u: Usage): number {
  const r = pricing().perMillion;
  return (
    (u.input * r.input + u.output * r.output + u.cacheRead * r.cacheRead + u.cacheWrite * r.cacheWrite) / 1_000_000 +
    u.externalInr
  );
}

export { formatMoney, formatTokens } from './format';
