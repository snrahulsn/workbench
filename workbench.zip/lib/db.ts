import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = process.env.WORKBENCH_DATA_DIR ?? path.join(process.cwd(), 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

declare global {
  // eslint-disable-next-line no-var
  var __workbench_db: Database.Database | undefined;
}

function open() {
  const db = new Database(path.join(DATA_DIR, 'workbench.db'));
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(`
    CREATE TABLE IF NOT EXISTS applications (
      slug        TEXT PRIMARY KEY,
      name        TEXT NOT NULL,
      summary     TEXT NOT NULL,
      pack_path   TEXT NOT NULL,
      manifest    TEXT NOT NULL,
      skills      TEXT NOT NULL,
      readme      TEXT NOT NULL,
      mcp         TEXT NOT NULL,
      templates   TEXT NOT NULL DEFAULT '[]',
      registered_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS drafts (
      id           TEXT PRIMARY KEY,
      name         TEXT NOT NULL,
      app_slug     TEXT NOT NULL REFERENCES applications(slug) ON DELETE CASCADE,
      seed         TEXT NOT NULL DEFAULT '',
      status       TEXT NOT NULL DEFAULT 'new',
      stage_index  INTEGER NOT NULL DEFAULT 0,
      template_id  TEXT,
      session_id   TEXT,
      created_at   TEXT NOT NULL,
      updated_at   TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS drafts_app ON drafts(app_slug);

    CREATE TABLE IF NOT EXISTS stage_data (
      draft_id   TEXT NOT NULL REFERENCES drafts(id) ON DELETE CASCADE,
      stage_id   TEXT NOT NULL,
      data       TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY (draft_id, stage_id)
    );

    CREATE TABLE IF NOT EXISTS messages (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      draft_id   TEXT NOT NULL REFERENCES drafts(id) ON DELETE CASCADE,
      role       TEXT NOT NULL,
      kind       TEXT NOT NULL DEFAULT 'text',
      body       TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS messages_draft ON messages(draft_id, id);

    CREATE TABLE IF NOT EXISTS usage (
      draft_id       TEXT PRIMARY KEY REFERENCES drafts(id) ON DELETE CASCADE,
      input_tokens   INTEGER NOT NULL DEFAULT 0,
      output_tokens  INTEGER NOT NULL DEFAULT 0,
      cache_read     INTEGER NOT NULL DEFAULT 0,
      cache_write    INTEGER NOT NULL DEFAULT 0,
      external_inr   REAL NOT NULL DEFAULT 0,
      updated_at     TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS suggestions (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      draft_id   TEXT NOT NULL REFERENCES drafts(id) ON DELETE CASCADE,
      title      TEXT NOT NULL,
      rationale  TEXT NOT NULL,
      impact     TEXT NOT NULL DEFAULT 'medium',
      status     TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS suggestions_draft ON suggestions(draft_id, status);

    CREATE TABLE IF NOT EXISTS process_maps (
      id         TEXT PRIMARY KEY,
      name       TEXT NOT NULL,
      steps      TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);
  return db;
}

export const db = global.__workbench_db ?? open();
if (process.env.NODE_ENV !== 'production') global.__workbench_db = db;

export const now = () => new Date().toISOString();
export const newId = (prefix: string) =>
  `${prefix}_${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-3)}`;
