import { query } from '@anthropic-ai/claude-agent-sdk';
import type { AgentDriver, AgentEvent, RunRequest } from './types';

/**
 * Driver for the Claude Agent SDK. Built-in tools are switched off
 * entirely, so the only things reachable are the workbench's own tools
 * and the application's tool servers.
 */
const claudeDriver: AgentDriver = {
  async *run(req: RunRequest): AsyncGenerator<AgentEvent> {
    const servers: Record<string, unknown> = { ...req.toolServers };
    if (req.localServer) servers.workbench = req.localServer;

    const pending = new Map<string, { server: string; tool: string }>();

    try {
      const stream = query({
        prompt: req.prompt,
        options: {
          systemPrompt: req.rules,
          // No file system, no shell, no web. Only declared tools.
          tools: [],
          mcpServers: servers as never,
          allowedTools: req.allowedTools,
          permissionMode: 'bypassPermissions',
          allowDangerouslySkipPermissions: true,
          // Do not inherit any machine-level configuration.
          settingSources: [],
          maxTurns: req.maxTurns,
          ...(req.model ? { model: req.model } : {}),
          ...(req.sessionId ? { resume: req.sessionId } : {}),
        },
      });

      for await (const msg of stream as AsyncIterable<Record<string, unknown>>) {
        const type = msg.type as string;

        if (type === 'system' && msg.subtype === 'init') {
          yield { type: 'session', sessionId: String(msg.session_id ?? '') };
          continue;
        }

        if (type === 'assistant') {
          const content = (msg.message as { content?: unknown[] } | undefined)?.content ?? [];
          for (const block of content as Record<string, unknown>[]) {
            if (block.type === 'text' && typeof block.text === 'string' && block.text.trim()) {
              yield { type: 'text', text: block.text };
            }
            if (block.type === 'tool_use') {
              const full = String(block.name ?? '');
              const parts = full.split('__');
              const server = parts.length >= 3 ? parts[1] : 'workbench';
              const tool = parts.length >= 3 ? parts.slice(2).join('__') : full;
              const id = String(block.id ?? tool);
              pending.set(id, { server, tool });
              if (!HIDDEN_TOOLS.has(tool)) {
                yield { type: 'tool_start', id, server, tool, label: humanise(tool) };
              }
            }
          }
          const usage = (msg.message as { usage?: Record<string, number> } | undefined)?.usage;
          if (usage) {
            yield {
              type: 'usage',
              input: usage.input_tokens ?? 0,
              output: usage.output_tokens ?? 0,
              cacheRead: usage.cache_read_input_tokens ?? 0,
              cacheWrite: usage.cache_creation_input_tokens ?? 0,
            };
          }
          continue;
        }

        if (type === 'user') {
          const content = (msg.message as { content?: unknown[] } | undefined)?.content ?? [];
          for (const block of content as Record<string, unknown>[]) {
            if (block.type !== 'tool_result') continue;
            const id = String(block.tool_use_id ?? '');
            const meta = pending.get(id);
            pending.delete(id);
            const ok = !block.is_error;
            const summary = summarise(block.content);
            if (!meta || !HIDDEN_TOOLS.has(meta.tool)) {
              yield { type: 'tool_end', id, ok, summary };
            }
            if (meta && ok) {
              const control = controlSignal(meta.tool, summary);
              if (control) yield control;
            }
          }
          continue;
        }

        if (type === 'result') {
          const subtype = String(msg.subtype ?? 'success');
          if (subtype !== 'success' && msg.is_error) {
            yield { type: 'error', message: plainError(String(msg.result ?? subtype)) };
          }
          yield { type: 'done', reason: subtype };
        }
      }
    } catch (e) {
      yield { type: 'error', message: plainError(e) };
    }
  },
};

/**
 * What the person sees while the assistant works. Bookkeeping calls are
 * not shown at all — they are noise, not progress.
 */
const HIDDEN_TOOLS = new Set(['progress', 'describe_step', 'list_templates']);

const LABELS: Record<string, string> = {
  use_template: 'Choosing a starting point',
  save_step: 'Writing this down',
  revise_step: 'Making changes',
  go_to_step: 'Opening the next step',
  propose_improvement: 'Noting something worth raising',
};

/**
 * Whatever the provider says, the person reads something that tells
 * them what to do about it — not a stack trace or a vendor's wording.
 */
function plainError(e: unknown): string {
  const raw = e instanceof Error ? e.message : String(e ?? '');
  const t = raw.toLowerCase();
  if (t.includes('limit') || t.includes('quota') || t.includes('rate')) {
    return 'This has run up against a usage limit for now. Your work is saved — try again shortly.';
  }
  if (t.includes('credit') || t.includes('billing')) {
    return 'This could not run because of an account limit. Your work is saved.';
  }
  if (t.includes('timeout') || t.includes('etimedout') || t.includes('abort')) {
    return 'That took too long and stopped. Your work is saved — try a smaller ask.';
  }
  if (t.includes('econnrefused') || t.includes('enotfound') || t.includes('network')) {
    return 'A tool this application depends on could not be reached. Your work is saved.';
  }
  return 'That stopped before it finished. Your work is saved — try again.';
}

function humanise(tool: string) {
  return LABELS[tool] ?? tool.replace(/[_-]+/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
}

function summarise(content: unknown): string {
  if (typeof content === 'string') return content.slice(0, 240);
  if (Array.isArray(content)) {
    const text = content
      .map((c) => (typeof c === 'object' && c && 'text' in c ? String((c as { text: unknown }).text) : ''))
      .join(' ')
      .trim();
    return text.slice(0, 240);
  }
  return '';
}

/** Workbench tools report their side effect in the summary so the UI can react. */
function controlSignal(tool: string, summary: string): AgentEvent | null {
  const stage = /\bstage=([a-z0-9_-]+)/i.exec(summary)?.[1];
  if (tool === 'go_to_step' && stage) return { type: 'stage_changed', stageId: stage };
  if ((tool === 'save_step' || tool === 'use_template' || tool === 'revise_step') && stage) {
    return { type: 'data_changed', stageId: stage };
  }
  if (tool === 'propose_improvement') return { type: 'suggestion', title: summary.slice(0, 120) };
  return null;
}

export const agent: AgentDriver = claudeDriver;
export type { AgentEvent, RunRequest } from './types';
