import { createSdkMcpServer, tool } from '@anthropic-ai/claude-agent-sdk';
import { z } from 'zod';
import type { Operation } from 'fast-json-patch';
import {
  addSuggestion, getAllStageData, getDraft, getStageData, mergeStageData,
  patchStageData, stageById, updateDraft, type Draft,
} from '../draft';
import type { Application } from '../pack';

/**
 * The workbench's own tools. Deliberately few, and none of them return
 * bulk data: results are one-line receipts. Everything the assistant
 * writes lands in the database and is drawn by the app, so the working
 * documents never travel back through the conversation.
 */

const ok = (text: string) => ({ content: [{ type: 'text' as const, text }] });
const err = (text: string) => ({ content: [{ type: 'text' as const, text }], isError: true });

const shape = (v: unknown): string => {
  if (Array.isArray(v)) return `${v.length} items`;
  if (v && typeof v === 'object') return `${Object.keys(v).length} fields`;
  if (typeof v === 'string') return `${v.length} chars`;
  return String(v);
};

export function buildWorkbenchServer(draft: Draft, app: Application) {
  const manifest = app.manifest;
  const stageIds = manifest.journey.map((s) => s.id);
  const primary = manifest.primaryArtifactStage;
  // Every step some template already knows how to fill in.
  const seededStages = new Set<string>([primary, ...app.templates.flatMap((t) => Object.keys(t.seeds))]);

  // Re-read so guards see writes made earlier in the same turn.
  const current = (): Draft => getDraft(draft.id) ?? draft;
  const templateChosen = () => !!current().templateId;

  return createSdkMcpServer({
    name: 'workbench',
    version: '1.0.0',
    tools: [
      tool(
        'list_templates',
        'List the starting templates available for this application, with how much of the real-world case mix each is expected to cover. Call this before writing anything.',
        {},
        async () => {
          if (!app.templates.length) return ok('No templates are configured for this application.');
          const lines = app.templates.map(
            (t) => `${t.id} — ${t.name}: ${t.summary} (covers about ${Math.round(t.coverage * 100)}%; matches: ${t.matches.join(', ')})`,
          );
          return ok(lines.join('\n'));
        },
      ),

      tool(
        'use_template',
        'Adopt a template as the starting point. This seeds every step it covers. Always prefer adopting the closest template and revising it over writing from scratch.',
        {
          template_id: z.string().describe('Template id from list_templates'),
          reason: z.string().describe('One sentence on why this template fits the request'),
        },
        async ({ template_id, reason }) => {
          const t = app.templates.find((x) => x.id === template_id);
          if (!t) return err(`No template with id "${template_id}". Call list_templates first.`);
          const seeded: string[] = [];
          for (const [stageId, bag] of Object.entries(t.seeds)) {
            if (!stageIds.includes(stageId)) continue;
            mergeStageData(draft.id, stageId, bag as Record<string, unknown>);
            seeded.push(stageId);
          }
          updateDraft(draft.id, { templateId: t.id, status: 'in_progress' });
          return ok(`Adopted "${t.name}". Seeded stage=${seeded[0] ?? primary} and ${Math.max(0, seeded.length - 1)} more. Reason recorded: ${reason}`);
        },
      ),

      tool(
        'describe_step',
        'Get the shape of what a step currently holds, without its contents. Use this to decide what to revise.',
        { step_id: z.string() },
        async ({ step_id }) => {
          const stage = stageById(manifest, step_id);
          if (!stage) return err(`Unknown step "${step_id}". Steps: ${stageIds.join(', ')}`);
          const bag = getStageData(draft.id, step_id);
          const keys = Object.keys(bag);
          if (!keys.length) return ok(`Step "${step_id}" (${stage.name}) is empty. It should produce: ${stage.produces.join(', ') || 'anything'}.`);
          return ok(`Step "${step_id}" (${stage.name}) holds: ${keys.map((k) => `${k} → ${shape(bag[k])}`).join('; ')}`);
        },
      ),

      tool(
        'save_step',
        'Write the contents of a step. Use only when no template applies or when a template has already been adopted.',
        {
          step_id: z.string(),
          data: z.record(z.unknown()).describe('Keys must match what the step produces'),
        },
        async ({ step_id, data }) => {
          const stage = stageById(manifest, step_id);
          if (!stage) return err(`Unknown step "${step_id}". Steps: ${stageIds.join(', ')}`);
          // Any step a template covers must come from a template first.
          if (manifest.agent.templateFirst && seededStages.has(step_id) && !templateChosen()) {
            return err(
              `"${step_id}" is one of the steps the templates cover, so it cannot be written from scratch. ` +
                `Call list_templates, adopt the closest with use_template, then revise_step for whatever differs.`,
            );
          }
          const unknownKeys = stage.produces.length ? Object.keys(data).filter((k) => !stage.produces.includes(k)) : [];
          if (unknownKeys.length) {
            return err(`Step "${step_id}" does not accept: ${unknownKeys.join(', ')}. It produces: ${stage.produces.join(', ')}.`);
          }
          mergeStageData(draft.id, step_id, data as Record<string, unknown>);
          updateDraft(draft.id, { status: 'in_progress' });
          const summary = Object.entries(data).map(([k, v]) => `${k}=${shape(v)}`).join(', ');
          return ok(`Saved stage=${step_id} (${summary}).`);
        },
      ),

      tool(
        'revise_step',
        'Change part of a step with a JSON Patch. Preferred over save_step: it is smaller and leaves the rest untouched.',
        {
          step_id: z.string(),
          operations: z
            .array(
              z.object({
                op: z.enum(['add', 'remove', 'replace', 'move', 'copy', 'test']),
                path: z.string().describe('JSON Pointer, e.g. /checks/3/enabled'),
                value: z.unknown().optional(),
                from: z.string().optional(),
              }),
            )
            .min(1),
        },
        async ({ step_id, operations }) => {
          if (!stageById(manifest, step_id)) return err(`Unknown step "${step_id}".`);
          try {
            patchStageData(draft.id, step_id, operations as unknown as Operation[]);
            updateDraft(draft.id, { status: 'in_progress' });
            return ok(`Revised stage=${step_id} with ${operations.length} change(s).`);
          } catch (e) {
            return err(`Could not apply the changes: ${e instanceof Error ? e.message : 'invalid patch'}`);
          }
        },
      ),

      tool(
        'go_to_step',
        'Move the person to a step once it is ready for them to look at.',
        { step_id: z.string() },
        async ({ step_id }) => {
          const idx = stageIds.indexOf(step_id);
          if (idx < 0) return err(`Unknown step "${step_id}".`);
          updateDraft(draft.id, { stageIndex: idx });
          return ok(`Opened stage=${step_id}.`);
        },
      ),

      tool(
        'propose_improvement',
        'Raise a change that would make this process faster or safer, beyond what was asked. Use sparingly and concretely.',
        {
          title: z.string().max(90),
          rationale: z.string().max(400),
          impact: z.enum(['low', 'medium', 'high']),
        },
        async ({ title, rationale, impact }) => {
          addSuggestion(draft.id, title, rationale, impact);
          return ok(`Raised: ${title}`);
        },
      ),

      tool(
        'progress',
        'Check which steps already have content, so you do not redo work.',
        {},
        async () => {
          const all = getAllStageData(draft.id);
          const lines = manifest.journey.map((s) => {
            const bag = all[s.id] ?? {};
            const done = s.produces.length ? s.produces.every((k) => bag[k] !== undefined) : Object.keys(bag).length > 0;
            return `${s.id}: ${done ? 'done' : Object.keys(bag).length ? 'partial' : 'empty'}`;
          });
          const d = current();
          return ok(`Template: ${d.templateId ?? 'none chosen'}\n${lines.join('\n')}`);
        },
      ),
    ],
  });
}

/** Fully-qualified names of the workbench tools, for the allow-list. */
export const WORKBENCH_TOOL_NAMES = [
  'list_templates', 'use_template', 'describe_step', 'save_step',
  'revise_step', 'go_to_step', 'propose_improvement', 'progress',
].map((n) => `mcp__workbench__${n}`);
