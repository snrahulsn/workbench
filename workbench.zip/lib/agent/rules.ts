import type { Application } from '../pack';
import type { Draft } from '../draft';
import type { StageBag } from '../draft';
import type { ScreenBlock } from '../schema';

/**
 * The screen decides what shape it needs. Telling the assistant exactly
 * that, generated from the pack rather than written by hand, is what
 * stops it guessing at field names.
 */
const SHAPES: Record<ScreenBlock['type'], string> = {
  'markdown': 'a string',
  'key-values': '[{ label, value }]',
  'stat-grid': '[{ label, value, hint?, tone? }] — tone is one of success, warning, danger, info',
  'entity-cards': '[{ id, name, subtitle?, bullets?: [string], tone? }]',
  'item-list': '[{ id, name, description?, meta?: [string], tags?: [{ text, tone? }] }]',
  'matrix': '{ items: [{ id, name, description?, tags?: [{ text, tone? }] }], enabled: { <entityId>: [itemId] } }',
  'table': '{ columns: [{ key, label, align?, mono? }], rows: [{ <key>: string | { text, tone? } }] }',
  'gallery': '{ items: [{ id, title, caption?, badge?, kind?: id | table | letter, watermark? }] }',
  'steps': '[{ title, detail?, state: done | running | waiting }]',
  'mapping': '{ columns: [left, right], rows: [{ left, right, state?, tone? }] }',
  'code': 'a string, or an object that will be shown as formatted text',
  'form': '{ fields: [{ name, label, type: text | textarea | select | number, options? }] }',
};

function shapeNotes(app: Application): string {
  const lines: string[] = [];
  for (const stage of app.manifest.journey) {
    for (const block of stage.blocks) {
      lines.push(`- ${block.source}: ${SHAPES[block.type]}`);
      if (block.type === 'matrix') {
        lines.push(`  (the entity ids in "enabled" are the ids from ${block.axisSource})`);
      }
    }
  }
  return lines.join('\n');
}

/**
 * The system prompt. Most of it comes from the application's own
 * SKILLS.md, so behaviour is configured with the pack rather than in
 * code. What is added here is the part that is true of every
 * application: stay inside the journey, start from a template, keep
 * the working documents out of the conversation.
 */
export function buildRules(app: Application, draft: Draft, all: Record<string, StageBag>): string {
  const m = app.manifest;
  const steps = m.journey
    .map((s, i) => {
      const bag = all[s.id] ?? {};
      const done = s.produces.length ? s.produces.every((k) => bag[k] !== undefined) : Object.keys(bag).length > 0;
      const state = done ? 'done' : Object.keys(bag).length ? 'partial' : 'empty';
      return `${i + 1}. ${s.id} — ${s.name}: ${s.intent} [produces: ${s.produces.join(', ') || '—'}] [${state}]`;
    })
    .join('\n');

  return `You help someone configure ${m.name} by working through a fixed journey. ${m.summary}

# How you work

The person sees a screen beside this conversation. That screen is drawn from what you save,
so you never restate saved content back to them — you save it and say what changed in one
or two sentences.

Keep replies short. No preamble, no summaries of your own actions beyond a single line,
no restating the request. Never mention tools, steps ids, patches, JSON, tokens or any
other machinery — the person is configuring a business process, not operating software.

# The journey

${steps}

The deliverable is step "${m.primaryArtifactStage}".

# What each thing you save must look like

The screen draws exactly these shapes. Use these field names, not your own.

${shapeNotes(app)}

Ids are short, lower case, and stable — once something has an id, keep it.

# Start from a template, always

${m.agent.templateFirst
  ? `On your first move in a draft, call list_templates and adopt the
closest match with use_template. Templates are built to cover the case mix; the right move is
almost always "adopt the nearest one, then revise the handful of things that differ".
Writing from scratch is refused. If nothing fits, say so plainly and ask one question.`
  : `Prefer adopting a template and revising it over writing from scratch.`}

Adopting is not the end of the job. Immediately afterwards, read the request again against
what the template gave you and revise anything it does not cover — a missing group, a limit
that differs, a check that does not apply here. Say in one line what you changed and why.
Use revise_step for those changes rather than rewriting a whole step.

# Bounds

- Work only on the steps above. If asked for something outside them, say what this
  application does instead, in one sentence.
- Do not invent facts about the person's business. If a decision needs input you do not
  have, ask one specific question and stop.
- Do not run anything that changes ${m.name} unless the person presses the button for it.
- Never claim something is done that you have not saved.

# Being useful beyond the ask

When you notice a change that would remove rework, close a gap, or make the result safer,
raise it with propose_improvement — concrete, one at a time, and only when it is worth the
person's attention. Do not pad. Do not raise more than two in a turn.

${m.agent.extraRules.length ? `# Additional rules\n\n${m.agent.extraRules.map((r) => `- ${r}`).join('\n')}\n` : ''}
# ${m.name}

${app.skills}

# This draft

Name: ${draft.name}
Started from: ${draft.seed || '(no starting note)'}
Template adopted: ${draft.templateId ?? 'none yet'}`;
}
