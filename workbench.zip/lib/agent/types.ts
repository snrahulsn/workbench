/**
 * The workbench talks to an assistant through this interface only.
 * Swapping the driver in lib/agent/index.ts is the whole migration.
 */

export type AgentEvent =
  | { type: 'session'; sessionId: string }
  | { type: 'text'; text: string }
  | { type: 'tool_start'; id: string; server: string; tool: string; label: string }
  | { type: 'tool_end'; id: string; ok: boolean; summary: string }
  | { type: 'stage_changed'; stageId: string }
  | { type: 'data_changed'; stageId: string }
  | { type: 'suggestion'; title: string }
  | { type: 'usage'; input: number; output: number; cacheRead: number; cacheWrite: number }
  | { type: 'done'; reason: string }
  | { type: 'error'; message: string };

export type ToolSpec = {
  /** Bare name as the application exposes it. */
  name: string;
  description: string;
  /** JSON Schema object for the parameters. */
  schema: Record<string, unknown>;
};

export type RunRequest = {
  prompt: string;
  /** Operating rules. Sent as the system prompt and cached between turns. */
  rules: string;
  /** Fully-qualified tool names the assistant may call. Everything else is unreachable. */
  allowedTools: string[];
  /** External tool servers, in Model Context Protocol form. */
  toolServers: Record<string, unknown>;
  /** In-process tools the workbench itself provides. */
  localServer?: unknown;
  sessionId?: string | null;
  model?: string;
  maxTurns: number;
};

export interface AgentDriver {
  run(req: RunRequest): AsyncGenerator<AgentEvent>;
}
