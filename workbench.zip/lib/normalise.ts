/**
 * The screens rely on a few small shapes. Rather than trusting whatever
 * arrives, the app repairs what it can — missing ids, a matrix handed
 * over as a bare list, tags given as plain strings — so a screen never
 * breaks because a field was named slightly differently.
 */

const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_|_$/g, '')
    .slice(0, 48) || 'item';

const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);

/** Common near-misses, repaired rather than shown as "Untitled". */
const ALIASES: Record<string, string> = {
  label: 'name',
  heading: 'name',
  desc: 'description',
  points: 'bullets',
  highlights: 'bullets',
};

/** Shapes that own their field names and must not be rewritten. */
const isProgressRow = (o: Record<string, unknown>) => 'state' in o && 'title' in o;
const isStat = (o: Record<string, unknown>) => 'label' in o && 'value' in o;

function applyAliases(o: Record<string, unknown>): Record<string, unknown> {
  const out = { ...o };
  for (const [from, to] of Object.entries(ALIASES)) {
    if (out[to] === undefined && out[from] !== undefined) {
      out[to] = out[from];
      delete out[from];
    }
  }
  return out;
}

function withIds(list: unknown[]): unknown[] {
  const seen = new Set<string>();
  return list.map((raw, i) => {
    if (!isObj(raw)) return raw;
    const o = isProgressRow(raw) || isStat(raw) ? { ...raw } : applyAliases(raw);
    if (!isProgressRow(raw) && !isStat(raw)) {
      let id = typeof o.id === 'string' && o.id.trim() ? o.id.trim() : slug(String(o.name ?? o.title ?? `item_${i + 1}`));
      while (seen.has(id)) id = `${id}_${i + 1}`;
      seen.add(id);
      o.id = id;
    }
    if (Array.isArray(o.tags)) {
      o.tags = o.tags.map((t) => (typeof t === 'string' ? { text: t } : t));
    }
    if (typeof o.meta === 'string') o.meta = [o.meta];
    return o;
  });
}

/** A matrix may arrive as a bare list of items; fill in the rest. */
function asMatrix(value: unknown): unknown {
  if (Array.isArray(value)) return { items: withIds(value), enabled: {} };
  if (!isObj(value)) return value;
  const out = { ...value };
  if (Array.isArray(out.items)) out.items = withIds(out.items);
  if (!isObj(out.enabled)) out.enabled = {};
  return out;
}

/** A gallery may arrive as a bare list too. */
function asGallery(value: unknown): unknown {
  if (Array.isArray(value)) return { items: withIds(value) };
  if (isObj(value) && Array.isArray(value.items)) return { ...value, items: withIds(value.items) };
  return value;
}

const looksLikeMatrix = (v: unknown) =>
  isObj(v) && (Array.isArray(v.items) || isObj(v.enabled));

const looksLikeGallery = (v: unknown) =>
  isObj(v) && Array.isArray(v.items) && (v.items as unknown[]).some((i) => isObj(i) && ('title' in i || 'caption' in i));

/**
 * Applied to everything written into a step, whether by the assistant or
 * by a tool. Keys are matched by what the value looks like, not by name,
 * so packs stay free to call things whatever suits them.
 */
export function normaliseBag(bag: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(bag)) {
    if (Array.isArray(value) && value.some((v) => isObj(v) && ('name' in v || 'title' in v || 'label' in v))) {
      out[key] = withIds(value);
    } else if (looksLikeGallery(value)) {
      out[key] = asGallery(value);
    } else if (looksLikeMatrix(value)) {
      out[key] = asMatrix(value);
    } else {
      out[key] = value;
    }
  }
  return out;
}
