import { applyPatch, type Operation } from 'fast-json-patch';
import { db, newId, now } from './db';
import { normaliseBag } from './normalise';
import { getApplication, type Application } from './pack';
import type { DraftStatus, Manifest, Stage } from './schema';

export type Draft = {
  id: string;
  name: string;
  appSlug: string;
  seed: string;
  status: DraftStatus;
  stageIndex: number;
  templateId: string | null;
  sessionId: string | null;
  createdAt: string;
  updatedAt: string;
};

type DraftRow = {
  id: string; name: string; app_slug: string; seed: string; status: string;
  stage_index: number; template_id: string | null; session_id: string | null;
  created_at: string; updated_at: string;
};

const toDraft = (r: DraftRow): Draft => ({
  id: r.id, name: r.name, appSlug: r.app_slug, seed: r.seed,
  status: r.status as DraftStatus, stageIndex: r.stage_index,
  templateId: r.template_id, sessionId: r.session_id,
  createdAt: r.created_at, updatedAt: r.updated_at,
});

export function listDrafts(): Draft[] {
  return (db.prepare('SELECT * FROM drafts WHERE status != ? ORDER BY updated_at DESC').all('archived') as DraftRow[]).map(toDraft);
}

export function getDraft(id: string): Draft | null {
  const r = db.prepare('SELECT * FROM drafts WHERE id = ?').get(id) as DraftRow | undefined;
  return r ? toDraft(r) : null;
}

export function createDraft(input: { name: string; appSlug: string; seed: string }): Draft {
  const id = newId('d');
  const ts = now();
  db.prepare(
    `INSERT INTO drafts (id,name,app_slug,seed,status,stage_index,created_at,updated_at)
     VALUES (?,?,?,?,'new',0,?,?)`,
  ).run(id, input.name, input.appSlug, input.seed, ts, ts);
  db.prepare('INSERT INTO usage (draft_id,updated_at) VALUES (?,?)').run(id, ts);
  return getDraft(id)!;
}

export function updateDraft(id: string, patch: Partial<Pick<Draft, 'name' | 'status' | 'stageIndex' | 'templateId' | 'sessionId'>>) {
  const map: Record<string, string> = {
    name: 'name', status: 'status', stageIndex: 'stage_index',
    templateId: 'template_id', sessionId: 'session_id',
  };
  const sets: string[] = [];
  const vals: unknown[] = [];
  for (const [k, v] of Object.entries(patch)) {
    if (v === undefined || !(k in map)) continue;
    sets.push(`${map[k]} = ?`);
    vals.push(v);
  }
  if (!sets.length) return getDraft(id);
  sets.push('updated_at = ?');
  vals.push(now(), id);
  db.prepare(`UPDATE drafts SET ${sets.join(', ')} WHERE id = ?`).run(...vals);
  return getDraft(id);
}

export function duplicateDraft(id: string): Draft | null {
  const src = getDraft(id);
  if (!src) return null;
  const copy = createDraft({ name: `${src.name} (copy)`, appSlug: src.appSlug, seed: src.seed });
  const rows = db.prepare('SELECT stage_id, data FROM stage_data WHERE draft_id = ?').all(id) as { stage_id: string; data: string }[];
  const ins = db.prepare('INSERT INTO stage_data (draft_id,stage_id,data,updated_at) VALUES (?,?,?,?)');
  for (const r of rows) ins.run(copy.id, r.stage_id, r.data, now());
  return updateDraft(copy.id, { templateId: src.templateId, stageIndex: src.stageIndex });
}

export function deleteDraft(id: string) {
  db.prepare('DELETE FROM drafts WHERE id = ?').run(id);
}

/* --------------------------- stage data --------------------------- */

export type StageBag = Record<string, unknown>;

export function getStageData(draftId: string, stageId: string): StageBag {
  const r = db.prepare('SELECT data FROM stage_data WHERE draft_id = ? AND stage_id = ?').get(draftId, stageId) as { data: string } | undefined;
  return r ? (JSON.parse(r.data) as StageBag) : {};
}

export function getAllStageData(draftId: string): Record<string, StageBag> {
  const rows = db.prepare('SELECT stage_id, data FROM stage_data WHERE draft_id = ?').all(draftId) as { stage_id: string; data: string }[];
  return Object.fromEntries(rows.map((r) => [r.stage_id, JSON.parse(r.data) as StageBag]));
}

export function setStageData(draftId: string, stageId: string, data: StageBag) {
  const clean = normaliseBag(data);
  db.prepare(
    `INSERT INTO stage_data (draft_id,stage_id,data,updated_at) VALUES (?,?,?,?)
     ON CONFLICT(draft_id,stage_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at`,
  ).run(draftId, stageId, JSON.stringify(clean), now());
  db.prepare('UPDATE drafts SET updated_at = ? WHERE id = ?').run(now(), draftId);
}

export function mergeStageData(draftId: string, stageId: string, partial: StageBag) {
  setStageData(draftId, stageId, { ...getStageData(draftId, stageId), ...partial });
}

/** RFC 6902 patch, so revisions stay small instead of resending whole documents. */
export function patchStageData(draftId: string, stageId: string, ops: Operation[]) {
  const current = getStageData(draftId, stageId);
  const next = applyPatch(structuredClone(current), ops, true, false).newDocument as StageBag;
  setStageData(draftId, stageId, next);
  return next;
}

/* ---------------------------- messages ---------------------------- */

export type StoredMessage = { id: number; role: 'user' | 'assistant'; kind: string; body: string; createdAt: string };

export function addMessage(draftId: string, role: 'user' | 'assistant', body: string, kind = 'text') {
  db.prepare('INSERT INTO messages (draft_id,role,kind,body,created_at) VALUES (?,?,?,?,?)').run(draftId, role, kind, body, now());
}

export function listMessages(draftId: string): StoredMessage[] {
  return (db.prepare('SELECT id,role,kind,body,created_at FROM messages WHERE draft_id = ? ORDER BY id').all(draftId) as
    { id: number; role: string; kind: string; body: string; created_at: string }[])
    .map((r) => ({ id: r.id, role: r.role as 'user' | 'assistant', kind: r.kind, body: r.body, createdAt: r.created_at }));
}

/* ----------------------------- usage ------------------------------ */

export type Usage = { input: number; output: number; cacheRead: number; cacheWrite: number; externalInr: number };

export function getUsage(draftId: string): Usage {
  const r = db.prepare('SELECT * FROM usage WHERE draft_id = ?').get(draftId) as
    | { input_tokens: number; output_tokens: number; cache_read: number; cache_write: number; external_inr: number }
    | undefined;
  return {
    input: r?.input_tokens ?? 0,
    output: r?.output_tokens ?? 0,
    cacheRead: r?.cache_read ?? 0,
    cacheWrite: r?.cache_write ?? 0,
    externalInr: r?.external_inr ?? 0,
  };
}

export function addUsage(draftId: string, u: Partial<Usage>) {
  db.prepare(
    `INSERT INTO usage (draft_id,input_tokens,output_tokens,cache_read,cache_write,external_inr,updated_at)
     VALUES (@id,@i,@o,@cr,@cw,@x,@t)
     ON CONFLICT(draft_id) DO UPDATE SET
       input_tokens = input_tokens + @i, output_tokens = output_tokens + @o,
       cache_read = cache_read + @cr, cache_write = cache_write + @cw,
       external_inr = external_inr + @x, updated_at = @t`,
  ).run({ id: draftId, i: u.input ?? 0, o: u.output ?? 0, cr: u.cacheRead ?? 0, cw: u.cacheWrite ?? 0, x: u.externalInr ?? 0, t: now() });
}

/* --------------------------- suggestions -------------------------- */

export type Suggestion = { id: number; title: string; rationale: string; impact: string; status: string };

export function addSuggestion(draftId: string, title: string, rationale: string, impact: string) {
  db.prepare('INSERT INTO suggestions (draft_id,title,rationale,impact,created_at) VALUES (?,?,?,?,?)')
    .run(draftId, title, rationale, impact, now());
}

export function listSuggestions(draftId: string): Suggestion[] {
  return db.prepare("SELECT id,title,rationale,impact,status FROM suggestions WHERE draft_id = ? AND status = 'open' ORDER BY id DESC")
    .all(draftId) as Suggestion[];
}

export function resolveSuggestion(id: number, status: 'accepted' | 'dismissed') {
  db.prepare('UPDATE suggestions SET status = ? WHERE id = ?').run(status, id);
}

/* ----------------------------- helpers ---------------------------- */

export function draftContext(draftId: string): { draft: Draft; app: Application; manifest: Manifest } | null {
  const draft = getDraft(draftId);
  if (!draft) return null;
  const app = getApplication(draft.appSlug);
  if (!app) return null;
  return { draft, app, manifest: app.manifest };
}

export function stageById(manifest: Manifest, id: string): Stage | undefined {
  return manifest.journey.find((s) => s.id === id);
}

/** A stage counts as done when it has produced everything it promised. */
export function stageComplete(manifest: Manifest, all: Record<string, StageBag>, stageId: string): boolean {
  const stage = stageById(manifest, stageId);
  if (!stage) return false;
  const bag = all[stageId] ?? {};
  if (!stage.produces.length) return Object.keys(bag).length > 0;
  return stage.produces.every((k) => bag[k] !== undefined);
}

export function furthestReachable(manifest: Manifest, all: Record<string, StageBag>): number {
  let i = 0;
  while (i < manifest.journey.length - 1 && stageComplete(manifest, all, manifest.journey[i].id)) i++;
  return i;
}
