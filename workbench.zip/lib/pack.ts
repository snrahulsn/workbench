import fs from 'node:fs';
import path from 'node:path';
import matter from 'gray-matter';
import { ManifestSchema, McpConfigSchema, TemplateSchema, type Manifest, type McpConfig, type Template } from './schema';
import { db, now } from './db';

/* ------------------------------------------------------------------ *
 * An application pack is the only way an application enters the
 * workbench. Registration is deterministic: the same directory either
 * passes every check or it does not, and the reasons are listed.
 * ------------------------------------------------------------------ */

export const PACKS_DIR = process.env.WORKBENCH_PACKS_DIR ?? path.join(process.cwd(), 'packs');

/** Headings a pack's SKILLS.md must contain, in any order. */
export const REQUIRED_SKILL_SECTIONS = [
  'Scope',
  'Operating rules',
  'Template policy',
  'Refusals',
  'Tool reference',
] as const;

/** Headings a pack's README.md must contain. */
export const REQUIRED_README_SECTIONS = [
  'What this application does',
  'Journey',
  'Capabilities',
  'Configuration',
] as const;

export type CheckId =
  | 'files'
  | 'manifest'
  | 'mcp'
  | 'skills'
  | 'readme'
  | 'tools'
  | 'journey'
  | 'templates'
  | 'probe';

export type Check = {
  id: CheckId;
  label: string;
  required: boolean;
  ok: boolean;
  detail: string;
  items?: { ok: boolean; text: string }[];
};

export type PackFiles = {
  dir: string;
  manifestRaw: string | null;
  skills: string | null;
  readme: string | null;
  mcpRaw: string | null;
  templateFiles: { name: string; raw: string }[];
};

export type ValidationResult = {
  dir: string;
  checks: Check[];
  ok: boolean;
  manifest?: Manifest;
  mcp?: McpConfig;
  templates: Template[];
  skills: string;
  readme: string;
};

/* --------------------------- reading ----------------------------- */

export function readPack(dir: string): PackFiles {
  const read = (f: string) => {
    const p = path.join(dir, f);
    return fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : null;
  };
  const tplDir = path.join(dir, 'templates');
  const templateFiles = fs.existsSync(tplDir)
    ? fs
        .readdirSync(tplDir)
        .filter((f) => f.endsWith('.json'))
        .map((name) => ({ name, raw: fs.readFileSync(path.join(tplDir, name), 'utf8') }))
    : [];
  return {
    dir,
    manifestRaw: read('manifest.json'),
    skills: read('SKILLS.md'),
    readme: read('README.md'),
    mcpRaw: read('mcp.json'),
    templateFiles,
  };
}

export function listPackDirs(): string[] {
  if (!fs.existsSync(PACKS_DIR)) return [];
  return fs
    .readdirSync(PACKS_DIR, { withFileTypes: true })
    .filter((e) => e.isDirectory())
    .map((e) => path.join(PACKS_DIR, e.name));
}

/* -------------------------- validation --------------------------- */

const headings = (md: string) =>
  md
    .split('\n')
    .filter((l) => /^#{1,3}\s/.test(l))
    .map((l) => l.replace(/^#{1,3}\s+/, '').trim().toLowerCase());

export function validatePack(dir: string): ValidationResult {
  const files = readPack(dir);
  const checks: Check[] = [];
  let manifest: Manifest | undefined;
  let mcp: McpConfig | undefined;
  const templates: Template[] = [];

  /* 1. required files */
  const fileItems = [
    { ok: !!files.manifestRaw, text: 'manifest.json' },
    { ok: !!files.skills, text: 'SKILLS.md' },
    { ok: !!files.readme, text: 'README.md' },
    { ok: !!files.mcpRaw, text: 'mcp.json' },
  ];
  checks.push({
    id: 'files',
    label: 'Required files present',
    required: true,
    ok: fileItems.every((i) => i.ok),
    detail: fileItems.every((i) => i.ok) ? 'All four files found.' : 'Some files are missing.',
    items: fileItems,
  });

  /* 2. manifest */
  if (files.manifestRaw) {
    try {
      manifest = ManifestSchema.parse(JSON.parse(files.manifestRaw));
      checks.push({ id: 'manifest', label: 'Manifest is valid', required: true, ok: true, detail: `${manifest.name} · ${manifest.journey.length} steps` });
    } catch (e) {
      checks.push({
        id: 'manifest',
        label: 'Manifest is valid',
        required: true,
        ok: false,
        detail: e instanceof Error ? e.message.slice(0, 800) : 'Could not read manifest.json',
      });
    }
  } else {
    checks.push({ id: 'manifest', label: 'Manifest is valid', required: true, ok: false, detail: 'manifest.json is missing.' });
  }

  /* 3. mcp */
  if (files.mcpRaw) {
    try {
      mcp = McpConfigSchema.parse(JSON.parse(files.mcpRaw));
      const declared = manifest?.mcp.servers ?? [];
      const items = declared.map((s) => ({ ok: !!mcp!.mcpServers[s], text: `server "${s}" defined` }));
      checks.push({
        id: 'mcp',
        label: 'Tool servers configured',
        required: true,
        ok: items.every((i) => i.ok) && declared.length > 0,
        detail: declared.length ? `${declared.length} declared` : 'No servers declared in the manifest.',
        items,
      });
    } catch (e) {
      checks.push({ id: 'mcp', label: 'Tool servers configured', required: true, ok: false, detail: e instanceof Error ? e.message.slice(0, 400) : 'Could not read mcp.json' });
    }
  } else {
    checks.push({ id: 'mcp', label: 'Tool servers configured', required: true, ok: false, detail: 'mcp.json is missing.' });
  }

  /* 4. skills */
  if (files.skills) {
    const hs = headings(matter(files.skills).content);
    const items = REQUIRED_SKILL_SECTIONS.map((s) => ({ ok: hs.includes(s.toLowerCase()), text: s }));
    checks.push({
      id: 'skills',
      label: 'Operating rules complete',
      required: true,
      ok: items.every((i) => i.ok),
      detail: 'SKILLS.md must cover every section so the assistant is bounded.',
      items,
    });
  } else {
    checks.push({ id: 'skills', label: 'Operating rules complete', required: true, ok: false, detail: 'SKILLS.md is missing.' });
  }

  /* 5. readme */
  if (files.readme) {
    const hs = headings(files.readme);
    const items = REQUIRED_README_SECTIONS.map((s) => ({ ok: hs.includes(s.toLowerCase()), text: s }));
    checks.push({
      id: 'readme',
      label: 'Documentation complete',
      required: true,
      ok: items.every((i) => i.ok),
      detail: 'README.md must describe the application for whoever configures it next.',
      items,
    });
  } else {
    checks.push({ id: 'readme', label: 'Documentation complete', required: true, ok: false, detail: 'README.md is missing.' });
  }

  /* 6. tools referenced by the journey are all allow-listed */
  if (manifest) {
    const allowed = new Set([...manifest.tools.read, ...manifest.tools.write]);
    const referenced = new Set<string>();
    for (const st of manifest.journey) {
      st.fetch.forEach((f) => referenced.add(f.tool));
      st.submit?.tools.forEach((t) => referenced.add(t.tool));
      st.actions.forEach((a) => a.tool && referenced.add(a.tool));
      st.blocks.forEach((b) => {
        if (b.type === 'form') referenced.add(b.submitTool);
        if (b.type === 'matrix' && b.onToggleTool) referenced.add(b.onToggleTool);
      });
    }
    const items = [...referenced].map((t) => ({ ok: allowed.has(t), text: t }));
    checks.push({
      id: 'tools',
      label: 'Every referenced tool is allow-listed',
      required: true,
      ok: items.every((i) => i.ok),
      detail: allowed.size ? `${allowed.size} tools allowed, ${referenced.size} referenced` : 'No tools allow-listed.',
      items,
    });
  }

  /* 7. journey is internally consistent */
  if (manifest) {
    const stageIds = new Set(manifest.journey.map((s) => s.id));
    const producedAnywhere = new Set<string>();
    manifest.journey.forEach((s) => s.produces.forEach((p) => producedAnywhere.add(p)));
    manifest.journey.forEach((s) => s.fetch.forEach((f) => producedAnywhere.add(f.into)));

    const items: { ok: boolean; text: string }[] = [];
    for (const s of manifest.journey) {
      for (const r of s.requires) items.push({ ok: stageIds.has(r), text: `${s.id} requires ${r}` });
      for (const b of s.blocks) {
        items.push({ ok: producedAnywhere.has(b.source), text: `${s.id} shows "${b.source}"` });
        if (b.type === 'matrix') items.push({ ok: producedAnywhere.has(b.axisSource), text: `${s.id} axis "${b.axisSource}"` });
      }
      // An action waits on data keys, not on step ids.
      for (const a of s.actions) {
        for (const r of a.requires) items.push({ ok: producedAnywhere.has(r), text: `${s.id}/${a.id} waits for "${r}"` });
      }
    }
    items.push({ ok: stageIds.has(manifest.primaryArtifactStage), text: `deliverable step "${manifest.primaryArtifactStage}" exists` });
    checks.push({
      id: 'journey',
      label: 'Journey is internally consistent',
      required: true,
      ok: items.every((i) => i.ok),
      detail: `${manifest.journey.length} steps`,
      items: items.filter((i) => !i.ok).length ? items.filter((i) => !i.ok) : items.slice(0, 4),
    });
  }

  /* 8. templates */
  for (const tf of files.templateFiles) {
    try {
      templates.push(TemplateSchema.parse(JSON.parse(tf.raw)));
    } catch {
      /* reported below */
    }
  }
  if (manifest) {
    const parsedAll = templates.length === files.templateFiles.length;
    const seedsPrimary = templates.filter((t) => t.seeds[manifest!.primaryArtifactStage]);
    checks.push({
      id: 'templates',
      label: 'Starting templates supplied',
      required: true,
      ok: parsedAll && seedsPrimary.length > 0,
      detail: !parsedAll
        ? 'One or more template files could not be read.'
        : seedsPrimary.length
          ? `${templates.length} templates, ${seedsPrimary.length} seed the deliverable`
          : 'At least one template must seed the deliverable step.',
      items: templates.map((t) => ({ ok: true, text: `${t.name} — covers about ${Math.round(t.coverage * 100)}%` })),
    });
  }

  const ok = checks.filter((c) => c.required).every((c) => c.ok);
  return { dir, checks, ok, manifest, mcp, templates, skills: files.skills ?? '', readme: files.readme ?? '' };
}

/* -------------------------- registration ------------------------- */

export function registerPack(dir: string): { ok: boolean; slug?: string; checks: Check[] } {
  const res = validatePack(dir);
  if (!res.ok || !res.manifest || !res.mcp) return { ok: false, checks: res.checks };
  const m = res.manifest;
  db.prepare(
    `INSERT INTO applications (slug,name,summary,pack_path,manifest,skills,readme,mcp,templates,registered_at)
     VALUES (@slug,@name,@summary,@pack_path,@manifest,@skills,@readme,@mcp,@templates,@registered_at)
     ON CONFLICT(slug) DO UPDATE SET
       name=@name, summary=@summary, pack_path=@pack_path, manifest=@manifest,
       skills=@skills, readme=@readme, mcp=@mcp, templates=@templates, registered_at=@registered_at`,
  ).run({
    slug: m.slug,
    name: m.name,
    summary: m.summary,
    pack_path: dir,
    manifest: JSON.stringify(m),
    skills: res.skills,
    readme: res.readme,
    mcp: JSON.stringify(res.mcp),
    templates: JSON.stringify(res.templates),
    registered_at: now(),
  });
  return { ok: true, slug: m.slug, checks: res.checks };
}

/* ---------------------------- access ----------------------------- */

export type Application = {
  slug: string;
  name: string;
  summary: string;
  packPath: string;
  manifest: Manifest;
  skills: string;
  readme: string;
  mcp: McpConfig;
  templates: Template[];
  registeredAt: string;
};

type Row = {
  slug: string; name: string; summary: string; pack_path: string;
  manifest: string; skills: string; readme: string; mcp: string;
  templates: string; registered_at: string;
};

const hydrate = (r: Row): Application => ({
  slug: r.slug,
  name: r.name,
  summary: r.summary,
  packPath: r.pack_path,
  manifest: JSON.parse(r.manifest),
  skills: r.skills,
  readme: r.readme,
  mcp: JSON.parse(r.mcp),
  templates: JSON.parse(r.templates),
  registeredAt: r.registered_at,
});

export function getApplication(slug: string): Application | null {
  const r = db.prepare('SELECT * FROM applications WHERE slug = ?').get(slug) as Row | undefined;
  return r ? hydrate(r) : null;
}

export function listApplications(): Application[] {
  return (db.prepare('SELECT * FROM applications ORDER BY name').all() as Row[]).map(hydrate);
}

/** Registers every pack on disk that passes validation. Safe to call repeatedly. */
export function syncPacksFromDisk(): { slug: string; ok: boolean }[] {
  return listPackDirs().map((dir) => {
    const r = registerPack(dir);
    return { slug: r.slug ?? path.basename(dir), ok: r.ok };
  });
}
