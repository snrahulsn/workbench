import { z } from 'zod';

/* ------------------------------------------------------------------ *
 * Screen blocks
 *
 * A block never contains data. It names a `source` — a key in the
 * stage's data bag — and describes how to draw whatever is there.
 * The shape of the data each block expects is documented in
 * docs/SCREEN_SCHEMA.md and enforced at render time.
 * ------------------------------------------------------------------ */

const BlockBase = z.object({
  title: z.string().optional(),
  description: z.string().optional(),
  source: z.string(),
  /** Hide the block until the source key exists. */
  hideWhenEmpty: z.boolean().default(true),
});

export const ScreenBlockSchema = z.discriminatedUnion('type', [
  BlockBase.extend({ type: z.literal('key-values') }),
  BlockBase.extend({ type: z.literal('markdown') }),
  BlockBase.extend({ type: z.literal('stat-grid'), columns: z.number().int().min(2).max(4).default(4) }),
  BlockBase.extend({
    type: z.literal('entity-cards'),
    columns: z.number().int().min(2).max(4).default(3),
    selectable: z.boolean().default(false),
    /** State key that holds the selected entity id (shared across blocks/stages). */
    selectionKey: z.string().optional(),
  }),
  BlockBase.extend({
    type: z.literal('item-list'),
    /** Column headings for the compact meta columns, left to right. */
    meta: z.array(z.string()).default([]),
  }),
  BlockBase.extend({
    type: z.literal('matrix'),
    /** Data key holding the axis entities (usually the same source as entity-cards). */
    axisSource: z.string(),
    selectionKey: z.string().optional(),
    /** Tool called when a cell is toggled. Omit to keep the change local to the draft. */
    onToggleTool: z.string().optional(),
  }),
  BlockBase.extend({ type: z.literal('table'), dense: z.boolean().default(false) }),
  BlockBase.extend({ type: z.literal('gallery'), columns: z.number().int().min(2).max(6).default(4) }),
  BlockBase.extend({ type: z.literal('steps') }),
  BlockBase.extend({ type: z.literal('mapping') }),
  BlockBase.extend({ type: z.literal('code'), language: z.string().default('json') }),
  BlockBase.extend({
    type: z.literal('form'),
    /** Tool invoked with the form values on submit. */
    submitTool: z.string(),
    submitLabel: z.string().default('Save'),
  }),
]);
export type ScreenBlock = z.infer<typeof ScreenBlockSchema>;

/* ------------------------------------------------------------------ *
 * Stage actions — buttons the app renders under the screen.
 * ------------------------------------------------------------------ */

export const StageActionSchema = z.object({
  id: z.string(),
  label: z.string(),
  hint: z.string().optional(),
  variant: z.enum(['primary', 'secondary']).default('secondary'),
  /** What pressing it does. */
  kind: z.enum(['prompt', 'tool', 'advance']),
  /** kind=prompt: message sent to the agent as if the user typed it. */
  prompt: z.string().optional(),
  /** kind=tool: application tool invoked directly by the app, no agent turn. */
  tool: z.string().optional(),
  args: z.record(z.unknown()).optional(),
  /** Only enabled once these stage ids have data. */
  requires: z.array(z.string()).default([]),
  /** Only enabled once this stage's submit has completed. */
  requiresSubmit: z.boolean().default(false),
});
export type StageAction = z.infer<typeof StageActionSchema>;

/* ------------------------------------------------------------------ *
 * Journey stage
 * ------------------------------------------------------------------ */

export const StageSchema = z.object({
  id: z.string().regex(/^[a-z][a-z0-9_-]*$/, 'stage id must be kebab or snake case'),
  name: z.string(),
  /** One line under the stage heading. Written for the person doing the work. */
  intent: z.string(),
  blocks: z.array(ScreenBlockSchema).default([]),
  actions: z.array(StageActionSchema).default([]),
  /** Data keys this stage is responsible for producing. */
  produces: z.array(z.string()).default([]),
  /** Stage ids that must have data before this one is reachable. */
  requires: z.array(z.string()).default([]),
  /** Marks the stage that writes into the target application. */
  submit: z
    .object({
      label: z.string(),
      hint: z.string().optional(),
      /** Ordered application tools run by the app, not the agent. */
      tools: z.array(
        z.object({
          tool: z.string(),
          label: z.string(),
          /** Values pulled from stage data and passed to the tool. */
          argsFrom: z.record(z.string()).default({}),
        }),
      ),
    })
    .optional(),
  /**
   * Data the app fetches itself when the stage opens, so the agent never
   * has to carry it. Results land in `produces` keys.
   */
  fetch: z
    .array(z.object({ tool: z.string(), into: z.string(), args: z.record(z.unknown()).default({}) }))
    .default([]),
});
export type Stage = z.infer<typeof StageSchema>;

/* ------------------------------------------------------------------ *
 * Templates — the agent must start from one of these.
 * ------------------------------------------------------------------ */

export const TemplateSchema = z.object({
  id: z.string(),
  name: z.string(),
  summary: z.string(),
  /** Free-text signals used to match a request to this template. */
  matches: z.array(z.string()).min(1),
  /** Rough share of real-world cases this template is expected to cover. */
  coverage: z.number().min(0).max(1).default(0.5),
  /** Stage data this template seeds, keyed by stage id. */
  seeds: z.record(z.record(z.unknown())),
});
export type Template = z.infer<typeof TemplateSchema>;

/* ------------------------------------------------------------------ *
 * Manifest
 * ------------------------------------------------------------------ */

export const ManifestSchema = z.object({
  schemaVersion: z.literal(1),
  slug: z.string().regex(/^[a-z][a-z0-9-]*$/),
  name: z.string(),
  summary: z.string(),
  /**
   * What this application can do, in shared vocabulary. Used by the
   * process mapper to suggest where the application fits a workflow.
   */
  capabilities: z.array(z.string()).min(1),
  /** Business inputs and outputs, for the same purpose. */
  consumes: z.array(z.string()).default([]),
  produces: z.array(z.string()).default([]),

  agent: z
    .object({
      /** Leave unset to use the deployment default. */
      model: z.string().optional(),
      maxTurnsPerMessage: z.number().int().min(1).max(40).default(12),
      maxToolResultChars: z.number().int().min(200).max(20000).default(1500),
      /** Refuse to author an artifact before a template has been chosen. */
      templateFirst: z.boolean().default(true),
      /** Extra sentences appended to the operating rules. */
      extraRules: z.array(z.string()).default([]),
    })
    .default({}),

  mcp: z.object({
    /** Server names, each of which must exist in mcp.json. */
    servers: z.array(z.string()).min(1),
  }),

  /**
   * Every application tool the agent may call, by bare name. Anything
   * not listed here is unreachable, whatever the MCP server exposes.
   */
  tools: z.object({
    read: z.array(z.string()).default([]),
    write: z.array(z.string()).default([]),
  }),

  journey: z.array(StageSchema).min(2),

  /** Stage id whose data is the deliverable. Template policy applies here. */
  primaryArtifactStage: z.string(),

  publish: z
    .object({
      label: z.string().default('Publish'),
      requiresSubmit: z.boolean().default(true),
    })
    .default({}),
});
export type Manifest = z.infer<typeof ManifestSchema>;

/* ------------------------------------------------------------------ *
 * MCP configuration
 * ------------------------------------------------------------------ */

export const McpServerSchema = z.union([
  z.object({
    type: z.literal('stdio').default('stdio'),
    command: z.string(),
    args: z.array(z.string()).default([]),
    env: z.record(z.string()).default({}),
  }),
  z.object({
    type: z.literal('http'),
    url: z.string().url(),
    headers: z.record(z.string()).default({}),
  }),
  z.object({
    type: z.literal('sse'),
    url: z.string().url(),
    headers: z.record(z.string()).default({}),
  }),
]);

export const McpConfigSchema = z.object({
  mcpServers: z.record(McpServerSchema),
});
export type McpConfig = z.infer<typeof McpConfigSchema>;

/* ------------------------------------------------------------------ *
 * Draft lifecycle
 * ------------------------------------------------------------------ */

export const DRAFT_STATUSES = ['new', 'in_progress', 'published', 'locked', 'archived'] as const;
export type DraftStatus = (typeof DRAFT_STATUSES)[number];

export const STATUS_LABEL: Record<DraftStatus, string> = {
  new: 'new',
  in_progress: 'in progress',
  published: 'published',
  locked: 'locked',
  archived: 'archived',
};
