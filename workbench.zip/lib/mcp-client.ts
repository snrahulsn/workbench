import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { SSEClientTransport } from '@modelcontextprotocol/sdk/client/sse.js';
import type { McpConfig } from './schema';

/**
 * A direct client to the application's tool servers, used by the app
 * itself. The app calls tools for anything deterministic — loading a
 * screen, running a submit — so those calls cost nothing in the
 * conversation and cannot be got wrong by an assistant.
 */

type Server = McpConfig['mcpServers'][string];

function transportFor(cfg: Server) {
  if ('command' in cfg) {
    return new StdioClientTransport({
      command: cfg.command,
      args: cfg.args,
      env: { ...(process.env as Record<string, string>), ...cfg.env },
    });
  }
  const url = new URL(cfg.url);
  const requestInit = { headers: cfg.headers };
  return cfg.type === 'sse'
    ? new SSEClientTransport(url, { requestInit })
    : new StreamableHTTPClientTransport(url, { requestInit });
}

async function connect(cfg: Server) {
  const client = new Client({ name: 'workbench', version: '1.0.0' }, { capabilities: {} });
  await client.connect(transportFor(cfg));
  return client;
}

export type ToolCallResult = { ok: true; value: unknown } | { ok: false; error: string };

/** Calls one tool and closes the connection. Servers are expected to be stateless. */
export async function callTool(
  mcp: McpConfig,
  serverNames: string[],
  toolName: string,
  args: Record<string, unknown>,
): Promise<ToolCallResult> {
  for (const name of serverNames) {
    const cfg = mcp.mcpServers[name];
    if (!cfg) continue;
    let client: Client | undefined;
    try {
      client = await connect(cfg);
      const { tools } = await client.listTools();
      if (!tools.some((t) => t.name === toolName)) continue;
      const res = await client.callTool({ name: toolName, arguments: args });
      const content = (res.content ?? []) as { type: string; text?: string }[];
      const text = content.filter((c) => c.type === 'text').map((c) => c.text ?? '').join('\n');
      if (res.isError) return { ok: false, error: text || 'The tool reported a problem.' };
      try {
        return { ok: true, value: JSON.parse(text) };
      } catch {
        return { ok: true, value: text };
      }
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : 'Could not reach the tool server.' };
    } finally {
      await client?.close().catch(() => {});
    }
  }
  return { ok: false, error: `No server provides "${toolName}".` };
}

/** Lists every tool across the declared servers. Used when registering an application. */
export async function probeTools(mcp: McpConfig, serverNames: string[]) {
  const found: { server: string; tools: string[] }[] = [];
  const failed: { server: string; error: string }[] = [];
  for (const name of serverNames) {
    const cfg = mcp.mcpServers[name];
    if (!cfg) {
      failed.push({ server: name, error: 'not defined in mcp.json' });
      continue;
    }
    let client: Client | undefined;
    try {
      client = await connect(cfg);
      const { tools } = await client.listTools();
      found.push({ server: name, tools: tools.map((t) => t.name) });
    } catch (e) {
      failed.push({ server: name, error: e instanceof Error ? e.message : 'could not connect' });
    } finally {
      await client?.close().catch(() => {});
    }
  }
  return { found, failed };
}
