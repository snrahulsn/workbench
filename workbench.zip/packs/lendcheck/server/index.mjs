#!/usr/bin/env node
/**
 * Reference tool server for the LendCheck package.
 *
 * It speaks the same tool names a real LendCheck deployment would, and
 * returns representative results, so the workbench runs end to end
 * before anyone has a tenant. Swap mcp.json to point at the real server
 * and nothing else changes.
 *
 * Every tool is stateless: it takes what it needs as arguments and holds
 * nothing between calls.
 */

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';

const json = (value) => ({ content: [{ type: 'text', text: JSON.stringify(value) }] });

const server = new McpServer({ name: 'lendcheck', version: '1.0.0' });

/* ----------------------------- reading ----------------------------- */

server.registerTool(
  'list_programmes',
  { description: 'Programmes and their variants that already exist.', inputSchema: {} },
  async () =>
    json([
      { name: 'Housing loan', variants: ['Salaried', 'Self-employed', 'NRI'] },
      { name: 'Business loan', variants: ['Proprietor', 'Partnership', 'Private limited'] },
      { name: 'Death claim', variants: ['Natural', 'Accidental'] },
    ]),
);

server.registerTool(
  'list_borrower_types',
  { description: 'Borrower types seen in past cases, with how often each appears.', inputSchema: {} },
  async () =>
    json([
      { id: 'salaried', name: 'Salaried — private sector', share: 0.61 },
      { id: 'nri', name: 'NRI borrower', share: 0.07 },
      { id: 'proprietor', name: 'Proprietor', share: 0.13 },
      { id: 'partnership', name: 'Partnership firm', share: 0.06 },
      { id: 'corporate', name: 'Private limited', share: 0.09 },
      { id: 'trust', name: 'Trust or society', share: 0.04 },
    ]),
);

server.registerTool(
  'list_checks',
  {
    description: 'Checks already in use across programmes, so names stay consistent.',
    inputSchema: { programme: z.string().optional() },
  },
  async () =>
    json([
      'Age at maturity', 'Minimum income', 'Obligation ratio', 'Loan to value',
      'Address consistency', 'Address proof recency', 'Employment tenure',
      'Bureau score floor', 'Salary credits reconcile', 'Clear property title',
    ]),
);

server.registerTool(
  'get_case_result',
  { description: 'How one sample case came out.', inputSchema: { case_id: z.string() } },
  async ({ case_id }) => json({ case_id, outcome: 'clean', checks_passed: 21, checks_failed: 0 }),
);

server.registerTool(
  'get_report',
  { description: 'The report produced for a case.', inputSchema: { case_id: z.string() } },
  async ({ case_id }) =>
    json({
      case_id,
      outcome: 'clean',
      columns: [
        { key: 'requirement', label: 'Requirement' },
        { key: 'documents', label: 'Documents used' },
        { key: 'checks', label: 'Checks' },
        { key: 'result', label: 'Result' },
        { key: 'note', label: 'Note' },
      ],
      rows: [
        { requirement: 'Identity', documents: 'Aadhaar, PAN', checks: '4 of 4', result: { text: 'pass', tone: 'success' }, note: '—' },
        { requirement: 'Address', documents: 'Aadhaar, electricity bill', checks: '3 of 3', result: { text: 'pass', tone: 'success' }, note: 'Matched allowing for formatting' },
        { requirement: 'Income', documents: 'Salary slips, Form 16', checks: '5 of 5', result: { text: 'pass', tone: 'success' }, note: 'Obligations at 41 per cent' },
        { requirement: 'Banking', documents: 'Six months of statements', checks: '3 of 3', result: { text: 'pass', tone: 'success' }, note: 'Credits reconcile within 1.8 per cent' },
        { requirement: 'Bureau', documents: 'Bureau report', checks: '2 of 2', result: { text: 'pass', tone: 'success' }, note: 'Score 761, no defaults' },
        { requirement: 'Property', documents: 'Valuation, sale deed', checks: '4 of 5', result: { text: 'review', tone: 'warning' }, note: 'One page illegible' },
      ],
    }),
);

server.registerTool(
  'get_routes',
  { description: 'How this draft’s interface maps onto the application.', inputSchema: {} },
  async () =>
    json({
      columns: ['This draft', 'LendCheck'],
      rows: [
        { left: 'POST /programme', right: 'POST /validation-workbench/create-program', state: 'connected', tone: 'success' },
        { left: 'POST /checks', right: 'POST /validation-workbench/import', state: 'connected', tone: 'success' },
        { left: 'GET /checks', right: 'GET /validation-workbench/rules-config', state: 'connected', tone: 'success' },
        { left: 'POST /cases', right: 'POST /validation/checklist/create-order', state: 'connected', tone: 'success' },
        { left: 'GET /cases/{id}', right: 'GET /validation/checklist/get-order', state: 'connected', tone: 'success' },
        { left: 'GET /report', right: 'GET /fetch_extraction_details', state: 'reshaped', tone: 'warning' },
        { left: 'POST /documents', right: 'POST /documents/upload', state: 'connected', tone: 'success' },
        { left: 'GET /requirements', right: null, state: 'open', tone: 'neutral' },
      ],
    }),
);

/* ----------------------------- writing ----------------------------- */

server.registerTool(
  'create_programme',
  { description: 'Create a sandbox programme.', inputSchema: { name: z.string() } },
  async ({ name }) => json({ programme: name, environment: 'sandbox', created: true }),
);

server.registerTool(
  'create_variant',
  {
    description: 'Add a variant per borrower type.',
    inputSchema: { borrower_types: z.array(z.any()).optional() },
  },
  async ({ borrower_types = [] }) => json({ variants: borrower_types.length || 1, environment: 'sandbox' }),
);

server.registerTool(
  'apply_checks',
  {
    description: 'Apply the checklist to the programme.',
    inputSchema: { checklist: z.any().optional() },
  },
  async ({ checklist }) => {
    const items = checklist?.items?.length ?? 0;
    const groups = Object.keys(checklist?.enabled ?? {}).length;
    return json({ checks_applied: items, variants: groups, conflicts: 0 });
  },
);

server.registerTool(
  'verify_setup',
  { description: 'Look for anything missing or contradictory in the set-up.', inputSchema: {} },
  async () => json({ problems: 0, message: 'Nothing missing' }),
);

server.registerTool(
  'set_check_enabled',
  {
    description: 'Turn one check on or off for one borrower type.',
    inputSchema: { group: z.string(), item: z.string(), enabled: z.boolean() },
  },
  async ({ group, item, enabled }) => json({ group, item, enabled }),
);

server.registerTool(
  'generate_cases',
  {
    description: 'Build invented case files for the given borrower types.',
    inputSchema: { borrower_types: z.array(z.string()).optional(), count: z.number().optional() },
  },
  async ({ borrower_types = ['salaried'], count = 12 }) =>
    json({
      generated: count,
      borrower_types,
      sample: {
        items: [
          { id: 'aadhaar', title: 'Aadhaar', caption: 'answer key', badge: 'phone photo', kind: 'id', watermark: 'SPECIMEN' },
          { id: 'pan', title: 'PAN card', caption: 'answer key', badge: 'scanned', kind: 'id', watermark: 'SPECIMEN' },
          { id: 'payslip', title: 'Salary slip', caption: 'answer key', badge: 'digital', kind: 'table', watermark: 'SPECIMEN' },
          { id: 'statement', title: 'Bank statement', caption: 'answer key', badge: 'digital', kind: 'table', watermark: 'SPECIMEN' },
          { id: 'employer', title: 'Employer letter', caption: 'answer key', badge: 'photocopy', kind: 'letter', watermark: 'SPECIMEN' },
          { id: 'bill', title: 'Electricity bill', caption: 'answer key', badge: 'phone photo', kind: 'letter', watermark: 'SPECIMEN' },
          { id: 'valuation', title: 'Valuation report', caption: 'answer key', badge: 'scanned', kind: 'letter', watermark: 'SPECIMEN' },
          { id: 'bureau', title: 'Bureau report', caption: 'answer key', badge: 'digital', kind: 'table', watermark: 'SPECIMEN' },
        ],
      },
      answer_key: [
        { label: 'Expected outcome', value: 'Clean pass' },
        { label: 'Planted problem', value: 'Name spelled differently on identity and payslip' },
        { label: 'Income', value: '₹84,200 a month' },
        { label: 'Bureau score', value: '761' },
        { label: 'Loan to value', value: '72 per cent' },
      ],
    }),
);

server.registerTool(
  'run_cases',
  {
    description: 'Put the generated cases through the checks and score them.',
    inputSchema: { count: z.number().optional() },
  },
  async ({ count = 12 }) =>
    json({
      scorecard: [
        { label: 'Right first time', value: '83%', hint: `10 of ${count} cases`, tone: 'success' },
        { label: 'Field accuracy', value: '96.4%', hint: '1,184 fields read' },
        { label: 'Needed review', value: '2', hint: 'both address proof age', tone: 'warning' },
        { label: 'Time per case', value: '41s', hint: 'eight documents' },
      ],
      case_results: {
        columns: [
          { key: 'case', label: 'Case' },
          { key: 'borrower', label: 'Borrower type' },
          { key: 'expected', label: 'Expected' },
          { key: 'actual', label: 'Actual' },
          { key: 'tripped', label: 'Tripped by' },
          { key: 'verdict', label: '', align: 'right' },
        ],
        rows: [
          { case: '1', borrower: 'NRI', expected: 'Clean', actual: { text: 'Clean', tone: 'success' }, tripped: '—', verdict: 'as expected' },
          { case: '2', borrower: 'Salaried', expected: 'Clean', actual: { text: 'Clean', tone: 'success' }, tripped: '—', verdict: 'as expected' },
          { case: '3', borrower: 'Salaried', expected: 'Review', actual: { text: 'Review', tone: 'warning' }, tripped: 'Address proof recency', verdict: 'as expected' },
          { case: '4', borrower: 'Salaried', expected: 'Clean', actual: { text: 'Review', tone: 'warning' }, tripped: 'Address proof recency', verdict: 'unexpected' },
          { case: '5', borrower: 'Private limited', expected: 'Clean', actual: { text: 'Clean', tone: 'success' }, tripped: '—', verdict: 'as expected' },
          { case: '6', borrower: 'Proprietor', expected: 'Clean', actual: { text: 'Clean', tone: 'success' }, tripped: '—', verdict: 'as expected' },
          { case: '7', borrower: 'Partnership', expected: 'Clean', actual: { text: 'Clean', tone: 'success' }, tripped: '—', verdict: 'as expected' },
          { case: '8', borrower: 'Trust', expected: 'Clean', actual: { text: 'Clean', tone: 'success' }, tripped: '—', verdict: 'as expected' },
        ],
      },
    }),
);

await server.connect(new StdioServerTransport());
