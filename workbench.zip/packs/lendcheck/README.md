# LendCheck application package

## What this application does

LendCheck reads the documents behind a loan application or an insurance claim, checks them
against a lender's or insurer's own policy, and reports what is right, what is missing and
what contradicts something else in the file.

Configuring it means answering three questions: who borrows, what has to be true before a
case can go through, and how well that performs when you try it on realistic files.

## Journey

| Step | What happens |
|---|---|
| Brief | What the draft is for, and what was read to build it |
| Borrower types | Who borrows, and what documents each type actually brings |
| Checks | What has to be true, each one hard, review or note |
| Checklist | Which checks run for which borrower type, and the button that sets it up |
| Sample cases | Invented case files, captured the way real files arrive |
| Results | How the checks performed against what each case should have returned |
| Report | What LendCheck produced for one case |
| Interface | What this draft exposes to callers, and where each route lands |

The deliverable is the **Checks** step. Templates must be adopted before anything is written
into it.

## Capabilities

Declared for the process mapper, so this application can be suggested when someone maps a
workflow that involves any of them:

document extraction · document validation · identity verification · address verification ·
income assessment · credit bureau check · property title check · checklist enforcement ·
case adjudication

Consumes: scanned documents, loan application, claim file, credit policy.
Produces: extracted fields, validation report, exception list, audit trail.

## Configuration

### Files

```
packs/lendcheck/
  manifest.json     journey, screens, tools, submit sequence
  SKILLS.md         the assistant's operating rules
  README.md         this file
  mcp.json          where the tool server lives
  templates/        starting points, one JSON file each
```

### Pointing at a real environment

`mcp.json` ships pointing at the reference server in `server/`, which returns representative
data so the workbench runs end to end without a live tenant. To use a real one, replace the
entry:

```json
{
  "mcpServers": {
    "lendcheck": {
      "type": "http",
      "url": "https://<your-host>/mcp",
      "headers": { "Authorization": "Bearer ${LENDCHECK_TOKEN}" }
    }
  }
}
```

The tool names in `manifest.json` must match what that server exposes. Registration contacts
the server and fails if any declared tool is missing, so a mismatch is caught before anyone
opens a draft.

### Adding a template

Drop a JSON file in `templates/`. It needs an `id`, a `name`, a `summary`, the `matches`
phrases used to recognise when it applies, a `coverage` figure, and `seeds` keyed by step id.
Aim for four or five templates that between them cover the case mix; the assistant is required
to adopt one rather than write from scratch.

### Environment

| Variable | Needed for |
|---|---|
| `LENDCHECK_TOKEN` | A real tool server, if it authenticates |
