# Configuring the workbench for a real LendCheck tenant

Written for whoever picks this up next. The workbench itself is finished and application-neutral;
what remains is pointing the LendCheck package at a real deployment instead of the reference
tool server that ships with it.

Read [docs/APPLICATION_PACK.md](docs/APPLICATION_PACK.md) first. It is the contract; this file
is the LendCheck-specific part.

---

## What is already true

- `packs/lendcheck/` is a complete, passing package: manifest, operating rules, documentation,
  tool configuration and five templates.
- `packs/lendcheck/server/index.mjs` is a **reference** tool server. It speaks the right tool
  names and returns representative results so the journey runs end to end. It talks to nothing.
- The journey is: Brief → Borrower types → Checks → Checklist → Sample cases → Results →
  Report → Interface. The deliverable is **Checks**.
- Every registration check passes today:

```bash
npm run pack:validate -- packs/lendcheck
```

---

## The job

Replace the reference server with one that speaks to a real tenant, keeping the same tool names.
Nothing else has to change: the workbench never names a LendCheck endpoint, only a tool.

### 1. The tools to implement

Thirteen tools. Six read, seven write. Names must match exactly — registration contacts the
server and fails if any is missing.

#### Reading

| Tool | Arguments | Returns |
|---|---|---|
| `list_programmes` | — | `[{ name, variants: [string] }]` |
| `list_borrower_types` | — | `[{ id, name, share }]` — `share` is the fraction of past cases |
| `list_checks` | `{ programme? }` | `[string]` — names already in use, so new work reuses them |
| `get_case_result` | `{ case_id }` | `{ case_id, outcome, checks_passed, checks_failed }` |
| `get_report` | `{ case_id }` | A table: `{ columns: [{ key, label }], rows: [{ … }] }` |
| `get_routes` | — | A mapping: `{ columns: [left, right], rows: [{ left, right, state, tone }] }` |

#### Writing

| Tool | Arguments | Returns |
|---|---|---|
| `create_programme` | `{ name }` | `{ programme, environment, created }` |
| `create_variant` | `{ borrower_types: [entity] }` | `{ variants, environment }` |
| `apply_checks` | `{ checklist: { items, enabled } }` | `{ checks_applied, variants, conflicts }` |
| `verify_setup` | — | `{ problems, message }` |
| `set_check_enabled` | `{ group, item, enabled }` | echo of the same |
| `generate_cases` | `{ borrower_types?, count? }` | `{ generated, sample: { items }, answer_key }` |
| `run_cases` | `{ count? }` | `{ scorecard, case_results }` |

`create_programme`, `create_variant`, `apply_checks` and `verify_setup` are run **by the app**,
in that order, when the person presses the button on the Checklist step. The assistant cannot
call them. `generate_cases` and `run_cases` are the assistant's to call when asked.

Return shapes are the screen shapes in [docs/SCREEN_SCHEMA.md](docs/SCREEN_SCHEMA.md). Copy the
returns in `packs/lendcheck/server/index.mjs` — they are correct by construction, since the
journey runs against them.

### 2. Mapping onto the real API

The known LendCheck endpoint paths sit behind these tools. Verbs and body shapes were never
confirmed, so capture them from a live session before writing the client — do not guess.

| Tool | Likely endpoint |
|---|---|
| `create_programme` | `POST /validation-workbench/create-program` |
| `create_variant` | `POST /validation-workbench/create-sub-program` |
| `apply_checks` | `POST /validation-workbench/v2/import/{sub}` |
| `list_checks` | `GET /validation-workbench/v2/rules-config/{sub}` |
| `verify_setup` | local — check every rule set resolves to a rule that exists |
| `generate_cases` | your own document generator |
| `run_cases` | `POST /validation/checklist/create-order`, then poll `GET /validation/checklist/get-order/{id}` |
| `get_report` | `GET /fetch_extraction_details?order_id=` |

Two rules that are not negotiable:

- **Write only to a sandbox.** `create_programme` must create or target a disposable
  programme, never one a live customer is using. Enforce it in the server, not in a prompt.
- **No real applicant data.** `generate_cases` invents everything and watermarks every page.

### 3. Point the package at it

```json
{
  "mcpServers": {
    "lendcheck": {
      "type": "http",
      "url": "https://<host>/mcp",
      "headers": { "Authorization": "Bearer ${LENDCHECK_TOKEN}" }
    }
  }
}
```

Then re-run the checks with the probe on. The last check contacts the server and lists any tool
it could not find.

```bash
npm run pack:validate -- packs/lendcheck
```

---

## Templates are the lever

Five ship: salaried mortgage (~45%), self-employed or entity mortgage (~25%), unsecured business
loan (~15%), overseas borrower (~7%), death claim (~8%). The assistant is **refused** if it tries
to author a covered step without adopting one first.

Tune these against the real tenant. Pull the actual case mix out of `list_programmes` and past
cases, and make the templates match it. The measure of a good set: people adopt one and change
two or three things. If they are routinely fighting the template, add one — do not turn
`templateFirst` off.

A template file needs `id`, `name`, `summary`, `matches` (phrases that signal it), `coverage`,
and `seeds` keyed by stage id. Drop it in `packs/lendcheck/templates/` and re-run the checks.

---

## Changing the journey

Edit `journey` in `packs/lendcheck/manifest.json`. Steps, screens, buttons and the submit
sequence are all there. The checks catch a screen that reads data nothing produces, a button
that waits on a key that never appears, or a tool that is not allow-listed.

If you change what a step produces, update the operating rules in `SKILLS.md` to match — the
assistant is told the shapes automatically, but not the intent.

---

## Adding a second application

Copy `packs/lendcheck/` as a starting point. The only parts that need thought:

1. **`capabilities`** — plain words, shared vocabulary. This is what *Map a process* matches
   against, so "document extraction" is useful and "LendCheck OCR v2" is not.
2. **`journey`** — the steps someone actually walks through, in the language they use.
3. **`SKILLS.md`** — scope, operating rules, template policy, refusals, tool reference.
4. **templates** — four or five, covering the real case mix.

Everything else follows from those.

---

## Things that will bite

- **Tool names are the contract.** Rename one on the server and registration fails loudly,
  which is the intent.
- **`argsFrom` uses JSONPath** against the whole draft, plus `draft.name`, `draft.id`,
  `draft.seed`. A typo yields `undefined`, silently — check the submit result.
- **Stateless servers.** Each tool call carries what it needs. Nothing is held between calls.
- **Spend rates** are in `config/pricing.json`, in rupees per million tokens. Correct them
  rather than editing code.
- **The reference server has no auth and no state.** Do not ship it anywhere real.
