# Workbench

A workbench for configuring an application by working through its journey, with an assistant
beside you doing the drafting and the screen filling in as it goes.

Nothing about any particular application is written into this codebase. An application arrives
as a package — its journey, its screens, its tools, its starting templates and its operating
rules — and the workbench draws itself from that.

---

## Running it

```bash
npm install
npm run dev
```

Open <http://localhost:3100>. The LendCheck package in `packs/` registers itself on first load
and ships a reference tool server, so the whole journey runs before you have a live tenant.

The assistant runs through the Claude Agent SDK and needs whatever credentials that expects in
the environment. Swapping providers means replacing one file — see *Provider* below.

---

## How it fits together

```
packs/<slug>/            an application package: journey, screens, tools, templates, rules
  ↓ registration (every check must pass)
lib/pack.ts              validates and stores the package
  ↓
lib/view.ts              assembles a screen on the server, running the step's own data loads
  ↓
components/screens/      draws blocks from the package's screen definitions
  ↑
lib/agent/               a deliberately small, bounded assistant
  ↑
packs/<slug>/mcp.json    the application's tool servers
```

### What the app does, and what the assistant does

The split is deliberate. Anything deterministic belongs to the app, because it is then the same
every time, cannot be got wrong, and costs nothing in the conversation.

| The app does | The assistant does |
|---|---|
| Loads each screen's data by calling tools directly | Decides which template fits |
| Runs the submit sequence, in order, when the button is pressed | Revises what the template did not cover |
| Writes every switch flip and form entry | Answers questions about the work |
| Fills in the first step from what was typed | Raises improvements worth the person's attention |
| Repairs the shape of anything saved | |

### Keeping the conversation cheap

- Built-in tools are switched off entirely. The assistant sees the workbench's eight tools and
  the application's declared tools, and nothing else.
- The working documents never travel through the conversation. They are written to the database
  and drawn by the app; tools return one-line receipts.
- Revisions go through JSON Patch rather than resending a whole document.
- Bookkeeping calls are not surfaced to the person and not repeated back to the assistant.
- The operating rules are stable text, so they cache between turns.
- `maxTurnsPerMessage` in the package is a hard stop on a single reply.

Spend is tracked per draft and shown in rupees. Rates live in `config/pricing.json`.

---

## Registering an application

Applications screen → pick a package folder → **Run checks**. Every check must pass before the
button to register appears. The same checks run from the command line:

```bash
npm run pack:validate -- packs/lendcheck
```

The format is written up in [docs/APPLICATION_PACK.md](docs/APPLICATION_PACK.md), and the screen
blocks in [docs/SCREEN_SCHEMA.md](docs/SCREEN_SCHEMA.md).

---

## Templates

The assistant is not allowed to build a covered step from nothing. It must list the templates,
adopt the closest, and then revise what differs. Four or five templates should cover the case
mix between them; if people routinely find nothing fits, that is the signal to add one, not to
loosen the rule.

---

## Mapping a process

*Map a process* takes the steps of something an organisation does today and matches each one
against what the registered applications declare they can do. Steps with nothing against them
are the gaps. Matching is on the shared capability vocabulary in each package, so a newly
registered application becomes suggestable immediately.

---

## Drafts

A draft holds its own conversation, work and spend, and resumes where it was left.

`new` → `in progress` → `published` → `locked`, plus `archived`. Duplicating a draft copies the
work and resets the spend. Editing a published draft returns it to in progress.

Access is inherited from the target application; the workbench keeps no user directory.

---

## Provider

The assistant is reached through one interface, `lib/agent/types.ts`. `lib/agent/index.ts` is
the only file that knows which provider is in use. Model choice is per-package, or left to the
deployment default.

---

## Layout

```
app/                 screens and API routes
components/ui/       shadcn primitives
components/screens/  the block renderers
lib/
  schema.ts          package and screen schemas
  pack.ts            registration and validation
  draft.ts           drafts, step data, messages, spend
  view.ts            assembles a screen, runs a step's data loads
  normalise.ts       repairs the shape of anything saved
  mcp-client.ts      the app's own client to the application's tools
  agent/             the bounded assistant
docs/                the package format
packs/               application packages
config/pricing.json  rates
```

## Commands

| Command | What it does |
|---|---|
| `npm run dev` | Runs the workbench on port 3100 |
| `npm run build` | Production build |
| `npm run typecheck` | Types only |
| `npm run pack:validate -- <dir>` | Runs every registration check on a package |
