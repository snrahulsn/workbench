/**
 * Checks an application package from the command line, so a pack can be
 * validated in a pipeline before anyone tries to register it.
 *
 *   npm run pack:validate -- packs/lendcheck
 *   npm run pack:validate -- packs/lendcheck --no-probe
 */
import path from 'node:path';
import { validatePack, PACKS_DIR } from '../lib/pack';
import { probeTools } from '../lib/mcp-client';

const args = process.argv.slice(2);
const target = args.find((a) => !a.startsWith('--')) ?? 'packs/lendcheck';
const doProbe = !args.includes('--no-probe');
const dir = path.isAbsolute(target) ? target : path.join(process.cwd(), target);

const tick = (ok: boolean) => (ok ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m');

async function main() {
  console.log(`\nChecking ${path.relative(process.cwd(), dir) || dir}\n`);
  const res = validatePack(dir);
  const checks = [...res.checks];

  if (doProbe && res.manifest && res.mcp) {
    const { found, failed } = await probeTools(res.mcp, res.manifest.mcp.servers);
    const available = new Set(found.flatMap((f) => f.tools));
    const declared = [...res.manifest.tools.read, ...res.manifest.tools.write];
    checks.push({
      id: 'probe',
      label: 'Tool servers answer and expose every declared tool',
      required: true,
      ok: failed.length === 0 && declared.every((t) => available.has(t)),
      detail: failed.length ? failed.map((f) => `${f.server}: ${f.error}`).join('; ') : `${available.size} tools found`,
      items: declared.map((t) => ({ ok: available.has(t), text: t })),
    });
  }

  for (const c of checks) {
    console.log(`${tick(c.ok)} ${c.label}`);
    console.log(`   ${c.detail}`);
    for (const it of c.items ?? []) {
      if (!it.ok) console.log(`   \x1b[31m·\x1b[0m ${it.text}`);
    }
  }

  const ok = checks.filter((c) => c.required).every((c) => c.ok);
  console.log(`\n${ok ? '\x1b[32mReady to register.\x1b[0m' : '\x1b[31mNot ready.\x1b[0m'}\n`);
  process.exit(ok ? 0 : 1);
}

void PACKS_DIR;
main();
